﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Bingo
{
    class Program
    {
        public static List<Jogadores> jogador = new List<Jogadores>();
        static private string saveFile = @"SCORE.txt";
        

        public static List<string> getNome()
        {
            List<string> favoritos = new List<string>();
            StreamReader file = new StreamReader(saveFile);
            try
            {
                while (!file.EndOfStream)
                {
                    favoritos.Add(file.ReadLine());
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Ocorreu um erro.");
            }
            finally
            {
                file.Close();
            }
            return favoritos;
        }

        public static void saveNome(string nomeJog)
        {
            bool check = File.Exists(saveFile) ? true : false;
            StreamWriter file = new StreamWriter(saveFile, check);
            try
            {
                file.WriteLine(nomeJog);
            }
            catch (Exception)
            {
                Console.WriteLine("Ocorreu um erro.");
            }
            finally
            {
                file.Close();
            }
        }

        public static bool ficheiroExiste()
        {
            bool check = File.Exists(saveFile) ? true : false;
            return check;
        }



        static void Main(string[] args)
        {
            int z = 0;
            do
            {
                menu1();
            } while (z == 0);
            

            Console.WriteLine("FIM");
            Console.ReadKey();
        }



        static void menu1()
        {
            Console.Clear();
            Console.WriteLine("Opção 1 - Jogar \n" +
                              "Opçao 2 - Sair!");
            int e = 1;
            do
            {
                e = lerVal();

                switch (e)
                {
                    case 1:
                        menu2();
                        break;
                    case 2:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opção Invalida, Escolha uma Opção Correta!");
                        break;

                }
            } while (e > 2 || e < 0);
       
        }

        static void menu2()
        {
            Console.Clear();
            Console.WriteLine("Opção 1 - Indicar o Numero de Jogadores \n" +
                              "Opçao 2 - Voltar!");
            int e = 0;

            do
            {
                e = lerVal();
                switch (e)
                {
                    case 1:
                        numeroJogadores();
                        break;
                    case 2:
                        menu1(); break;
                    default:
                        Console.WriteLine("Opção Invalida, Escolha uma Opção Correta!");
                        break;

                }
            } while (e > 2 || e < 0);
        }

        static void menu3()
        {
            Console.Clear();
            Console.WriteLine("Opção 1 - Indicar o Nome de Jogadores \n" +
                              "Opçao 2 - Escolher Nome dos Favoritos!");
            int e = 0;

            do
            {
                e = lerVal();

                switch (e)
                {
                    case 1:
                        escreverNomes();
                        break;
                    case 2:
                        escolherNomes();
                        break;
                    default:
                        Console.WriteLine("Opção Invalida, Escolha uma Opção Correta!");
                        break;

                }
            } while (e > 2 || e < 0);
        }



        public static void numeroJogadores()
        {
            Console.Clear();
            Console.WriteLine("Qual o Numero de Jogadores? (1 até 5)");
            int jog = 0;
            do
            {
                jog = lerVal();
            } while (jog > 5);

            for(int i = 0; i < jog; i++)
            {
                jogador.Add(new Jogadores());
            }
            menu3();
        }

        private static int lerVal()
        { 
            bool flag = false;
            int numJog = 0;
            do
            {
                try
                {
                    numJog = int.Parse(Console.ReadLine());
                    flag = true;
                }
                catch (Exception)
                {
                    Console.WriteLine("Opção Invalida, Escolha uma Opção Correta!");
                    flag = false;
                }
            } while (!flag);
            return numJog;
        }

        private static void escreverNomes()
        {
            Console.Clear();

            for (int i = 0; i <= jogador.Count-1; i++)
            {
                //jogador[i] = new Jogadores();
                Console.WriteLine("Insira o Nome do Jogador {0}.", i+1);
                jogador[i].NomeJogador = Console.ReadLine();
                Console.WriteLine("Deseja guardar o Jogador {0} nos Favoritos? (S/N)", i + 1);
                bool flag;
                do
                {
                    string resposta = Console.ReadLine();
                    flag = true;
                    if (resposta == "s" || resposta == "S")
                    {
                        flag = true;
                    }
                    else if (resposta == "n" || resposta == "N")
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Insira uma Opçao Valida!");
                    }
                } while (flag == false);
                if (flag)
                {
                    saveNome(jogador[i].NomeJogador);
                }
            }

            System.Threading.Thread.Sleep(1000);
            menu3();
        }

        private static void escolherNomes()
        {
            List<string> favoritos = getNome();
            int numJog;

            for (int i = 0; i < jogador.Count; i++)
            {
                Console.Clear();
                for (int j = 0; j < favoritos.Count - 1; j++)
                {
                    Console.WriteLine(j + 1 + " - " + favoritos[j]);
                }
                Console.WriteLine("Qual o Nome do Jogador " + (i + 1));
                numJog = lerVal();
                jogador[i].NomeJogador = favoritos[numJog];
            }
            Console.ReadKey();
        }

        public void Comparador(Jogadores b)
        {
            byte cont = 0;
            bool bingo = false;
            int i = 0, j = 0, z = 0;

            do
            {
                for (i = 0; i < 5; i++)
                {
                    for (j = 0; j < 5; j++)
                    {
                        jogador[z].;
                    }
                }
                i++;
                j++;
                z++;
            } while (i != 5 && j != 5);


        }










    }
}
