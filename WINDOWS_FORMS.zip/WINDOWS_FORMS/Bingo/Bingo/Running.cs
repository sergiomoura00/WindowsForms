﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bingo
{
    public class Running
    {
        private List<byte> numeros = new List<byte>();

        private byte GerarNumeros1_99()
        {
            Random randNum = new Random();
            byte aleatorio = 0;
            bool repetido = false;

            do
            {
                aleatorio = (byte)randNum.Next(1, 99);
                if (!numeros.Any(x => x == aleatorio))
                {
                    repetido = true;
                }
            } while (!repetido);
            numeros.Add(aleatorio);

            System.Threading.Thread.Sleep(100);

            return aleatorio;
        }


        




    }
}
