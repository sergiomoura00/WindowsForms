﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bingo
{
    public class Jogadores
    {
        private string Nome;
        public CartaoBingo cartao = new CartaoBingo();

        public string NomeJogador
        {
            set { Nome = value; }
            get { return Nome; }
        }

        public void apresentarJogador()
        {
            Console.WriteLine("");
            Console.WriteLine(this.Nome);
            this.cartao.apresentarBoletim();
            Console.WriteLine("");
            
        }
    }
}
