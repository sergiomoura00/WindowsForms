﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bingo
{
    public class CartaoBingo
    {
        private byte[,] numeros = new byte[5, 5];

        public CartaoBingo()
        {
            numeros = GerarBoletim();
            Console.WriteLine("Cartão Bingo Criado!");
        }

        private byte GerarNumeros()
        {
            List<byte> nums = new List<byte>();
            Random randNum = new Random();
            byte aleatorio = 0;
            bool repetido = false;

            do
            {
                aleatorio = (byte)randNum.Next(1, 99);
                if (!nums.Any(x => x == aleatorio))
                {
                    repetido = true;
                }
            } while (!repetido);
            nums.Add(aleatorio);

            System.Threading.Thread.Sleep(100);

            return aleatorio;
        }

        private byte[,] GerarBoletim()
        {
            byte[,] numBoletim = new byte[5, 5];

            for (byte i = 0; i < 5; i++)
            {
                for (byte j = 0; j < 5; j++)
                {
                    numBoletim[i, j] = GerarNumeros();
                }
            }
            
            return numBoletim;
        }

        public void apresentarBoletim()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.Write("\n|");
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(this.numeros[i, j] + "|");
                }
            }
        }
    }
}