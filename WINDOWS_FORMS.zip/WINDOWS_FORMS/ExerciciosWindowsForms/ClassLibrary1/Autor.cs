﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Autor
    {
        private string _id;
        private string _nome;
        private List<Editora> _editorasUsadas = new List<Editora>();

        public string Id
        {
            get { return this._id; }
        }
        public string Nome
        {
            set { this._nome = value; }
            get { return this._nome; }
        }
        public List<Editora> EditorasUsadas
        {
            get { return this._editorasUsadas; }
        }

        public Autor()
        {
            _id = Guid.NewGuid().ToString();
        }

        public Autor(string nome, List<Editora> editorasUsadas) : this()
        {
            this._nome = nome ?? "";
            this._editorasUsadas = editorasUsadas;
        }

        public string ImprimeDados()
        {
            return string.Format("ID: {0}  |  NOME: {1}  |  LISTA: {2}", this._id, this._nome, this._editorasUsadas);
        }
    }
}
