﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Livro
    {
        private string _isbn, _titulo;
        private GeneroLivro _genero;
        private DateTime _dataPublicacao;
        private Editora _editora;

        public string Isbn
        {
            get { return this._isbn; }
        }
        public string Titulo
        {
            get { return this._titulo; }
        }
        public GeneroLivro Genero
        {
            get { return this._genero; }
        }
        public DateTime DataPublicacao
        {
            get { return this._dataPublicacao; }
        }
        public Editora Editora
        {
            get { return this._editora; }
        }


        public Livro(string isbn, string titulo, GeneroLivro genero, DateTime dataPublicacao, Editora editora)
        {
            if (!string.IsNullOrEmpty(isbn))
                this._isbn = isbn;
            else
                this._isbn = "";

            if (!string.IsNullOrEmpty(titulo))
                _titulo = titulo;
            else
                this._titulo = "";

            if (dataPublicacao != null)
                this._dataPublicacao = dataPublicacao;
            else
                this._dataPublicacao = new DateTime();

            this._genero = genero ?? new GeneroLivro();

            this._editora = editora ?? new Editora();

        }

        public string ImprimeDados()
        {
            return string.Format("ISBN: {0}  |  TITULO: {1}  |  GENERO: {2}  |  DATA: {3}  |  EDITORA: {4}", this._isbn, this._titulo, this._genero.ImprimeDados(), this._dataPublicacao.ToUniversalTime(), this._editora.ImprimeDados());
        }
    }
}
