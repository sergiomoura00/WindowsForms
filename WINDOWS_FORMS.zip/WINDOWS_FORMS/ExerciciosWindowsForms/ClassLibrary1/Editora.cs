﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Editora
    {
        private string _id, _nome;
       // public string Id, Nome;


        public string Id
        {
            get{ return _id; }
        }

        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public Editora()
        {
            _id = Guid.NewGuid().ToString();
        }

        public Editora(string nome) : this()
        {
            Nome = nome;
        }

        public string ImprimeDados()
        {
            return string.Format("ID: {0}  |  NOME: {1}", this._id, this._nome);
        }

    }
}
