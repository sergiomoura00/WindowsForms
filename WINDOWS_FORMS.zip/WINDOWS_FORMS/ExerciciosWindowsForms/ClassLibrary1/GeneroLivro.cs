﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class GeneroLivro
    {
        private string _id, _descricao;

        public string Id
        {
            get { return _id; }
        }

        public string Descricao
        {
            get { return _descricao; }
            set { _descricao = value; }
        }

        public GeneroLivro()
        {
            _id = Guid.NewGuid().ToString();
        }

        public GeneroLivro(string descricao) : this()
        {
            Descricao = descricao;
        }

        public string ImprimeDados()
        {
            return string.Format("ID: {0}  |  Descrição: {1}", this._id, this._descricao);
        }
    }
}
