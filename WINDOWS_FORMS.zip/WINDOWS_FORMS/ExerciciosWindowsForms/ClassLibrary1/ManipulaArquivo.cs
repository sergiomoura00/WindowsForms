﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ClassLibrary1
{
    public class ManipulaArquivo
    {
        public string arquivo;
        public ManipulaArquivo(string arquivo)
        {
            this.arquivo = arquivo;
        }

        public void Escrever<T>(T conteudo)
        {
            using (StreamWriter sw = new StreamWriter(this.arquivo, true))
            {
                sw.WriteLine(conteudo);
                sw.Close();
            }
        }

        public string Ler()
        {
            string conteudo = string.Empty;
            if (File.Exists(this.arquivo))
            {
                using (StreamReader sr = new StreamReader(this.arquivo))
                {
                    conteudo = sr.ReadToEnd();
                    sr.Close();
                }
            }
            return conteudo;
        }


    }
}
