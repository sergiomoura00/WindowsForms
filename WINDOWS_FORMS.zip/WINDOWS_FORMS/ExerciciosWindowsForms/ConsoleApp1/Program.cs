﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    class Program
    {
        static void Main(string[] args)
        {


            int[] array = { 3, 5, 7, 1, 10, 2, 23, 1, 9 };

            int numAprocurar = 9;
            bool encontrei = false;

            for(int i =0; i<array.Length;i++)
            {
                if (array[i] == numAprocurar)
                    encontrei = true;
            }
            foreach(int i in array)
            {
                if (i == numAprocurar)
                    encontrei = true;
            }

            int x = array.FirstOrDefault(XPTO => XPTO == numAprocurar);
            if (x > 0)
                encontrei = true;

            encontrei = array.FirstOrDefault(XPTO => XPTO == numAprocurar) > 0 ?
                true : false;


            Teste[] arrayteste = new Teste[3];
            arrayteste[0] = new Teste();
            arrayteste[1] = new Teste();
            arrayteste[2] = new Teste();

            arrayteste[0].Id = 100;
            arrayteste[0].Descricao = "xpto";
            arrayteste[1].Id = 200;
            arrayteste[1].Descricao = "abc";
            arrayteste[2].Id = 300;
            arrayteste[2].Descricao = "asasd";

            Teste xx =
            arrayteste.FirstOrDefault(obj => obj.Descricao == "abc" );

            Console.WriteLine(xx.Descricao+"|"+xx.Id);
            Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);

            xx.Id = 999;

            Console.WriteLine(xx.Descricao + "|" + xx.Id);
            Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);

            arrayteste[1].Descricao = "Antonio";

            Console.WriteLine(xx.Descricao + "|" + xx.Id);
            Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);


            //OPERADOR TERNÁRIO 
            //Utilização do símbolo ?
            //VALOR = CONDIÇÃO ? SE VERDADE : SE MENTIRA;

            //int a = xx.Id == 999 ? -1 : 0;
            xx.Id = 0;
            int a = xx.Id == 999 ?
                (arrayteste.Length > 3 ? 1: 2) : 3;

            /*
            char[] troll = nomeCompleto[0].ToCharArray();
            Array.Reverse(troll);
            string trollReverse = new string(troll);



            lblResultNome.Text = trollReverse;

           */










        }
    }


    public class Teste
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}
