﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace TesteClasses_Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Autor aa = new Autor() { Nome = "PABLOO" };
            Editora bb = new Editora() { Nome = "PORTO EDITORA" };
            GeneroLivro cc = new GeneroLivro() { Descricao = "QUALQUER COISA" };
            DateTime dateTime = new DateTime();
            
            Livro ZZ = new Livro("porto.pt", "PAPAPAPAPAPAAPA", cc, dateTime , bb);
            Console.WriteLine(ZZ.ImprimeDados());

            Console.ReadKey();
        }
    }
}
