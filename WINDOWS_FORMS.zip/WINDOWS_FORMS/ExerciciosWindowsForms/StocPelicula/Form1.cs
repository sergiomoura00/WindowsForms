﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassEscrever;

namespace StocPelicula
{
    public partial class Form1 : Form
    {
        public ManipulaArquivo arquivo = new ManipulaArquivo(@"D:\Sergio_Moura\testea.txt");
        public Form1()
        {
            InitializeComponent();
        }


        private void bttREGIST_Click(object sender, EventArgs e)
        {
            
            string Linha = txtBoxPROD.Text + txtBoxQTD.Text;
            lstBoxPelicula.Items.Add(Linha);
            arquivo.Escrever<string>(Linha);
            arquivo.Escrever<string>("");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //gpBoxRESULTS.Text = arquivo.Ler();
            //txtBoxPROD = lstBoxPelicula.SelectedIndex;
        }

        private void lstBoxPelicula_SelectedIndexChanged(object sender, EventArgs e)
        {
          //  txtBoxPROD.Text = lstBoxPelicula.SelectedIndex.ToString();
        }

        private void bttREGIST_MouseClick(object sender, MouseEventArgs e)
        {
            txtBoxPROD.Text = lstBoxPelicula.SelectedIndex;
        }
    }
}
