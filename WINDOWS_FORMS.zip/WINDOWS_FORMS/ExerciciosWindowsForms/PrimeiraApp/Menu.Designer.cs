﻿namespace PrimeiraApp
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ficheiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnFicheiroSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExemplos = new System.Windows.Forms.ToolStripMenuItem();
            this.janelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaCasc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaHor = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaVert = new System.Windows.Forms.ToolStripMenuItem();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.cumprimentos = new System.Windows.Forms.Button();
            this.fahrenheit = new System.Windows.Forms.Button();
            this.calc_notas = new System.Windows.Forms.Button();
            this.nome_email = new System.Windows.Forms.Button();
            this.horas_sao = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheiroToolStripMenuItem,
            this.mnExemplos,
            this.janelaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1019, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ficheiroToolStripMenuItem
            // 
            this.ficheiroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnFicheiroSair});
            this.ficheiroToolStripMenuItem.Name = "ficheiroToolStripMenuItem";
            this.ficheiroToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ficheiroToolStripMenuItem.Text = "Ficheiro";
            // 
            // mnFicheiroSair
            // 
            this.mnFicheiroSair.Name = "mnFicheiroSair";
            this.mnFicheiroSair.Size = new System.Drawing.Size(93, 22);
            this.mnFicheiroSair.Text = "Sair";
            this.mnFicheiroSair.Click += new System.EventHandler(this.mnFicheiroSair_Click);
            // 
            // mnExemplos
            // 
            this.mnExemplos.Name = "mnExemplos";
            this.mnExemplos.Size = new System.Drawing.Size(69, 20);
            this.mnExemplos.Text = "Exemplos";
            this.mnExemplos.Click += new System.EventHandler(this.mnExemplos_Click);
            // 
            // janelaToolStripMenuItem
            // 
            this.janelaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnJanelaCasc,
            this.mnJanelaHor,
            this.mnJanelaVert});
            this.janelaToolStripMenuItem.Name = "janelaToolStripMenuItem";
            this.janelaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.janelaToolStripMenuItem.Text = "Janela";
            // 
            // mnJanelaCasc
            // 
            this.mnJanelaCasc.Name = "mnJanelaCasc";
            this.mnJanelaCasc.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaCasc.Text = "Cascata";
            this.mnJanelaCasc.Click += new System.EventHandler(this.mnJanelaCasc_Click);
            // 
            // mnJanelaHor
            // 
            this.mnJanelaHor.Name = "mnJanelaHor";
            this.mnJanelaHor.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaHor.Text = "Horizontal";
            this.mnJanelaHor.Click += new System.EventHandler(this.mnJanelaHor_Click);
            // 
            // mnJanelaVert
            // 
            this.mnJanelaVert.Name = "mnJanelaVert";
            this.mnJanelaVert.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaVert.Text = "Vertical";
            this.mnJanelaVert.Click += new System.EventHandler(this.mnJanelaVert_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Controls.Add(this.cumprimentos);
            this.flowLayoutPanel1.Controls.Add(this.fahrenheit);
            this.flowLayoutPanel1.Controls.Add(this.calc_notas);
            this.flowLayoutPanel1.Controls.Add(this.nome_email);
            this.flowLayoutPanel1.Controls.Add(this.horas_sao);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(2, 27);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1014, 67);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // cumprimentos
            // 
            this.cumprimentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cumprimentos.Location = new System.Drawing.Point(3, 3);
            this.cumprimentos.Name = "cumprimentos";
            this.cumprimentos.Size = new System.Drawing.Size(163, 60);
            this.cumprimentos.TabIndex = 0;
            this.cumprimentos.Text = "Cumprimentos";
            this.cumprimentos.UseVisualStyleBackColor = true;
            this.cumprimentos.Click += new System.EventHandler(this.button1_Click);
            // 
            // fahrenheit
            // 
            this.fahrenheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fahrenheit.Location = new System.Drawing.Point(172, 3);
            this.fahrenheit.Name = "fahrenheit";
            this.fahrenheit.Size = new System.Drawing.Size(163, 60);
            this.fahrenheit.TabIndex = 1;
            this.fahrenheit.Text = "Fahrenheit";
            this.fahrenheit.UseVisualStyleBackColor = true;
            this.fahrenheit.Click += new System.EventHandler(this.button2_Click);
            // 
            // calc_notas
            // 
            this.calc_notas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calc_notas.Location = new System.Drawing.Point(341, 3);
            this.calc_notas.Name = "calc_notas";
            this.calc_notas.Size = new System.Drawing.Size(163, 60);
            this.calc_notas.TabIndex = 2;
            this.calc_notas.Text = "Calc. Notas";
            this.calc_notas.UseVisualStyleBackColor = true;
            this.calc_notas.Click += new System.EventHandler(this.button3_Click);
            // 
            // nome_email
            // 
            this.nome_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nome_email.Location = new System.Drawing.Point(510, 3);
            this.nome_email.Name = "nome_email";
            this.nome_email.Size = new System.Drawing.Size(163, 60);
            this.nome_email.TabIndex = 3;
            this.nome_email.Text = "Nome/Email";
            this.nome_email.UseVisualStyleBackColor = true;
            this.nome_email.Click += new System.EventHandler(this.nome_email_Click);
            // 
            // horas_sao
            // 
            this.horas_sao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.horas_sao.Location = new System.Drawing.Point(679, 3);
            this.horas_sao.Name = "horas_sao";
            this.horas_sao.Size = new System.Drawing.Size(163, 60);
            this.horas_sao.TabIndex = 4;
            this.horas_sao.Text = "Que Horas São?";
            this.horas_sao.UseVisualStyleBackColor = true;
            this.horas_sao.Click += new System.EventHandler(this.horas_sao_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 493);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ficheiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnFicheiroSair;
        private System.Windows.Forms.ToolStripMenuItem mnExemplos;
        private System.Windows.Forms.ToolStripMenuItem janelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaCasc;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaHor;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaVert;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button cumprimentos;
        private System.Windows.Forms.Button fahrenheit;
        private System.Windows.Forms.Button calc_notas;
        private System.Windows.Forms.Button nome_email;
        private System.Windows.Forms.Button horas_sao;
    }
}