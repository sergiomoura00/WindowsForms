﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmNotaFinal : Form
    {
        public frmNotaFinal()
        {
            InitializeComponent();
            this.Height = 240;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double NotaFinal = 0.0,
                T1 = double.Parse(txtPrimTeste.Text),
                T2 = double.Parse(txtSegTeste.Text),
                TP1 = double.Parse(txtPrimTrabPra.Text),
                TP2 = double.Parse(txtSegTrabPra.Text),
                TF = double.Parse(txtTrabFinal.Text);

            NotaFinal = Properties.Settings.Default.peso1 * (T1 + T2) / 2 +
                        Properties.Settings.Default.peso2 * (TP1 + TP2) / 2 +
                        Properties.Settings.Default.peso3 * TF;

            lblNotaFinal.Text = Math.Round(NotaFinal, 2).ToString();

            this.Height = 320;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            this.Height = 240;
            txtPrimTeste.Text =
            txtSegTeste.Text =
            txtPrimTrabPra.Text =
            txtSegTrabPra.Text =
            txtTrabFinal.Text = string.Empty;
        }

        private void txtNumeric_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Se o KeyChar (guardado na variável "e" que é um Unicode que corresponde à tecla que foi pressionada)
            //NÃO (atenção ao ! atrás) é um dígito, ignorar a tecla
            if (!char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Apenas números");
                //e.Handled = true; significa que o evento já foi "tratado"
                //será o mesmo que dizer: "Ignora a tecla que foi pressionada"
                e.Handled = true;
            }

            //Se o controlo que disparou este evento (é sempre uma TextBox)
            //tem no seu texto já 2 caracteres, ignora os seguintes
            if ((sender as TextBox).Text.Length >= 2)
                e.Handled = true;
        }
    }
}
