﻿namespace PrimeiraApp
{
    partial class frmNome_Email
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNomeCompleto = new System.Windows.Forms.TextBox();
            this.lblNomeCompleto = new System.Windows.Forms.Label();
            this.bttMostrar = new System.Windows.Forms.Button();
            this.lblMostraNome = new System.Windows.Forms.Label();
            this.lblMostraEmail1 = new System.Windows.Forms.Label();
            this.lblMostraEmail2 = new System.Windows.Forms.Label();
            this.lblResultNome = new System.Windows.Forms.Label();
            this.lblResultEmail1 = new System.Windows.Forms.Label();
            this.lblResultEmail2 = new System.Windows.Forms.Label();
            this.bttLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNomeCompleto
            // 
            this.txtNomeCompleto.Location = new System.Drawing.Point(101, 18);
            this.txtNomeCompleto.Name = "txtNomeCompleto";
            this.txtNomeCompleto.Size = new System.Drawing.Size(284, 20);
            this.txtNomeCompleto.TabIndex = 0;
            // 
            // lblNomeCompleto
            // 
            this.lblNomeCompleto.AutoSize = true;
            this.lblNomeCompleto.Location = new System.Drawing.Point(12, 21);
            this.lblNomeCompleto.Name = "lblNomeCompleto";
            this.lblNomeCompleto.Size = new System.Drawing.Size(82, 13);
            this.lblNomeCompleto.TabIndex = 1;
            this.lblNomeCompleto.Text = "Nome Completo";
            // 
            // bttMostrar
            // 
            this.bttMostrar.Location = new System.Drawing.Point(101, 55);
            this.bttMostrar.Name = "bttMostrar";
            this.bttMostrar.Size = new System.Drawing.Size(284, 47);
            this.bttMostrar.TabIndex = 2;
            this.bttMostrar.Text = "Ver";
            this.bttMostrar.UseVisualStyleBackColor = true;
            this.bttMostrar.Click += new System.EventHandler(this.bttMostrar_Click);
            // 
            // lblMostraNome
            // 
            this.lblMostraNome.AutoSize = true;
            this.lblMostraNome.Location = new System.Drawing.Point(187, 133);
            this.lblMostraNome.Name = "lblMostraNome";
            this.lblMostraNome.Size = new System.Drawing.Size(35, 13);
            this.lblMostraNome.TabIndex = 3;
            this.lblMostraNome.Text = "Nome";
            // 
            // lblMostraEmail1
            // 
            this.lblMostraEmail1.AutoSize = true;
            this.lblMostraEmail1.Location = new System.Drawing.Point(178, 158);
            this.lblMostraEmail1.Name = "lblMostraEmail1";
            this.lblMostraEmail1.Size = new System.Drawing.Size(44, 13);
            this.lblMostraEmail1.TabIndex = 4;
            this.lblMostraEmail1.Text = "E-mail 1";
            // 
            // lblMostraEmail2
            // 
            this.lblMostraEmail2.AutoSize = true;
            this.lblMostraEmail2.Location = new System.Drawing.Point(178, 183);
            this.lblMostraEmail2.Name = "lblMostraEmail2";
            this.lblMostraEmail2.Size = new System.Drawing.Size(44, 13);
            this.lblMostraEmail2.TabIndex = 5;
            this.lblMostraEmail2.Text = "E-mail 2";
            // 
            // lblResultNome
            // 
            this.lblResultNome.AutoSize = true;
            this.lblResultNome.Location = new System.Drawing.Point(261, 133);
            this.lblResultNome.Name = "lblResultNome";
            this.lblResultNome.Size = new System.Drawing.Size(35, 13);
            this.lblResultNome.TabIndex = 6;
            this.lblResultNome.Text = "Nome";
            // 
            // lblResultEmail1
            // 
            this.lblResultEmail1.AutoSize = true;
            this.lblResultEmail1.Location = new System.Drawing.Point(261, 158);
            this.lblResultEmail1.Name = "lblResultEmail1";
            this.lblResultEmail1.Size = new System.Drawing.Size(44, 13);
            this.lblResultEmail1.TabIndex = 7;
            this.lblResultEmail1.Text = "E-mail 1";
            // 
            // lblResultEmail2
            // 
            this.lblResultEmail2.AutoSize = true;
            this.lblResultEmail2.Location = new System.Drawing.Point(261, 183);
            this.lblResultEmail2.Name = "lblResultEmail2";
            this.lblResultEmail2.Size = new System.Drawing.Size(44, 13);
            this.lblResultEmail2.TabIndex = 8;
            this.lblResultEmail2.Text = "E-mail 2";
            // 
            // bttLimpar
            // 
            this.bttLimpar.Location = new System.Drawing.Point(101, 212);
            this.bttLimpar.Name = "bttLimpar";
            this.bttLimpar.Size = new System.Drawing.Size(284, 47);
            this.bttLimpar.TabIndex = 9;
            this.bttLimpar.Text = "Limpar";
            this.bttLimpar.UseVisualStyleBackColor = true;
            this.bttLimpar.Click += new System.EventHandler(this.bttLimpar_Click);
            // 
            // frmNome_Email
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 271);
            this.Controls.Add(this.bttLimpar);
            this.Controls.Add(this.lblResultEmail2);
            this.Controls.Add(this.lblResultEmail1);
            this.Controls.Add(this.lblResultNome);
            this.Controls.Add(this.lblMostraEmail2);
            this.Controls.Add(this.lblMostraEmail1);
            this.Controls.Add(this.lblMostraNome);
            this.Controls.Add(this.bttMostrar);
            this.Controls.Add(this.lblNomeCompleto);
            this.Controls.Add(this.txtNomeCompleto);
            this.Name = "frmNome_Email";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmNome_Email";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNomeCompleto;
        private System.Windows.Forms.Label lblNomeCompleto;
        private System.Windows.Forms.Button bttMostrar;
        private System.Windows.Forms.Label lblMostraNome;
        private System.Windows.Forms.Label lblMostraEmail1;
        private System.Windows.Forms.Label lblMostraEmail2;
        private System.Windows.Forms.Label lblResultNome;
        private System.Windows.Forms.Label lblResultEmail1;
        private System.Windows.Forms.Label lblResultEmail2;
        private System.Windows.Forms.Button bttLimpar;
    }
}