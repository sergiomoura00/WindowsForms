﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmFahrenheit : Form
    {
        public frmFahrenheit()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            /*
             * Ler o valor da textbox (é uma string)
             * Aplicar a fórmula (Texto - 32) / 1.8 e guardar o resultado
             * Escrever o resultado na outra textbox
             */
            double F = 0.0, C= 0.0;

            //TRATAMENTO DE UM POSSÍVEL ERRO
            //SE FOR COLOCADO TEXTO EM VEZ DE NÚMEROS DÁ ERRO
            //UM ERRO CHAMA-SE "EXCEPTION"
            try
            {
                //double.Parse é usado para strings
                F = double.Parse(txtFahrenheit.Text);
                //Convert.ToDouble é usado para objects
                //F = Convert.ToDouble(txtFahrenheit.Text);
                C = (F - 32) / 1.8;

                txtCelsius.Text = Math.Round(C, 2).ToString();
            }
            catch (FormatException)
            {
                //Avisar o utilizador
                MessageBox.Show("Apenas números");
            }
        }

        private void btnNovoCalculo_Click(object sender, EventArgs e)
        {
            //Colocar uma variável ou valr de string com "" é o mesmo
            //que dizer que essa string passa a ter o valor de string vazia
            //Em C#, podemos fazer isso de 2 formas:
            //atribuir ""
            //ou chamar o string.Empty
            //É INDIFERENTE!
            txtFahrenheit.Text = string.Empty;
            txtCelsius.Text = "";
        }
    }
}
