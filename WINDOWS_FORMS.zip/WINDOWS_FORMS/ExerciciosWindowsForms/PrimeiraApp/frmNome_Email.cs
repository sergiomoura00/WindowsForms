﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmNome_Email : Form
    {
        public frmNome_Email()
        {
            InitializeComponent();
        }

        private void bttMostrar_Click(object sender, EventArgs e)
        {
            string[] nomeCompleto = txtNomeCompleto.Text.Split(' ');
            lblResultNome.Text = nomeCompleto[0] + " " + nomeCompleto[nomeCompleto.Length -1];
            lblResultEmail1.Text = nomeCompleto[0].ToLower() + "." + nomeCompleto[nomeCompleto.Length - 1].ToLower() + "@xpto.pt";
            lblResultEmail2.Text = nomeCompleto[0][0].ToString().ToLower() + "." + nomeCompleto[nomeCompleto.Length - 1].ToLower() + "@xpto.pt";
        }

        private void bttLimpar_Click(object sender, EventArgs e)
        {
            txtNomeCompleto.Text = "";
            lblResultNome.Text = "Nome";
            lblResultEmail1.Text = "nome@xpto.pt";
            lblResultEmail2.Text = "nme@xpto.pt";
        }
    }
}
