﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void mnFicheiroSair_Click(object sender, EventArgs e)
        {
            DialogResult resultado =
            MessageBox.Show(
                "Tem a certeza que quer sair?",
                "A encerrar...",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);

            switch(resultado)
            {
                case DialogResult.Yes:
                case DialogResult.OK:
                    Application.Exit();
                    break;

            }

            if (resultado == DialogResult.Yes)
                Application.Exit();

        }

        private void mnExemplos_Click(object sender, EventArgs e)
        {

        }







       

        #region JANELAS

        private void mnJanelaCasc_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void mnJanelaHor_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnJanelaVert_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }


        #endregion




        #region EXERCICIOS

        private void button1_Click(object sender, EventArgs e)
        {
            frmCumprimentos f = this.MdiChildren.FirstOrDefault
                (xpto => xpto.GetType() == typeof(frmCumprimentos))
                as frmCumprimentos;

            if (f == null)
            {
                f = new frmCumprimentos();
                // f.MdiParent = this;
            }
            f.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmFahrenheit f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmFahrenheit)) as frmFahrenheit;

            if (f == null)
            {
                f = new frmFahrenheit();
                //f.MdiParent = this;
            }
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmNotaFinal f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmNotaFinal)) as frmNotaFinal;

            if (f == null)
            {
                f = new frmNotaFinal();
                //f.MdiParent = this;
            }
            f.Show();
        }

        private void nome_email_Click(object sender, EventArgs e)
        {
            frmNome_Email f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmNome_Email)) as frmNome_Email;

            if (f == null)
            {
                f = new frmNome_Email();
                //f.MdiParent = this;
            }
            f.Show();
        }

        private void horas_sao_Click(object sender, EventArgs e)
        {
            frmQueHorasSao f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmQueHorasSao)) as frmQueHorasSao;

            if (f == null)
            {
                f = new frmQueHorasSao();
                //f.MdiParent = this;
            }
            f.Show();
        }




        #endregion




    }
}
