﻿namespace PrimeiraApp
{
    partial class frmNotaFinal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSegTeste = new System.Windows.Forms.TextBox();
            this.txtPrimTeste = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSegTrabPra = new System.Windows.Forms.TextBox();
            this.txtPrimTrabPra = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTrabFinal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblNotaFinal = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSegTeste);
            this.groupBox1.Controls.Add(this.txtPrimTeste);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 87);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Testes";
            // 
            // txtSegTeste
            // 
            this.txtSegTeste.Location = new System.Drawing.Point(83, 57);
            this.txtSegTeste.Name = "txtSegTeste";
            this.txtSegTeste.Size = new System.Drawing.Size(27, 20);
            this.txtSegTeste.TabIndex = 3;
            this.txtSegTeste.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // txtPrimTeste
            // 
            this.txtPrimTeste.Location = new System.Drawing.Point(83, 20);
            this.txtPrimTeste.Name = "txtPrimTeste";
            this.txtPrimTeste.Size = new System.Drawing.Size(27, 20);
            this.txtPrimTeste.TabIndex = 2;
            this.txtPrimTeste.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "2º Teste";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "1º Teste";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(114, 170);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 1;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSegTrabPra);
            this.groupBox2.Controls.Add(this.txtPrimTrabPra);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(147, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(143, 87);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trab. Práticos";
            // 
            // txtSegTrabPra
            // 
            this.txtSegTrabPra.Location = new System.Drawing.Point(101, 57);
            this.txtSegTrabPra.Name = "txtSegTrabPra";
            this.txtSegTrabPra.Size = new System.Drawing.Size(27, 20);
            this.txtSegTrabPra.TabIndex = 3;
            this.txtSegTrabPra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // txtPrimTrabPra
            // 
            this.txtPrimTrabPra.Location = new System.Drawing.Point(101, 20);
            this.txtPrimTrabPra.Name = "txtPrimTrabPra";
            this.txtPrimTrabPra.Size = new System.Drawing.Size(27, 20);
            this.txtPrimTrabPra.TabIndex = 2;
            this.txtPrimTrabPra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "2º Trab. Prático";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "1º Trab. Prático";
            // 
            // txtTrabFinal
            // 
            this.txtTrabFinal.Location = new System.Drawing.Point(95, 135);
            this.txtTrabFinal.Name = "txtTrabFinal";
            this.txtTrabFinal.Size = new System.Drawing.Size(27, 20);
            this.txtTrabFinal.TabIndex = 5;
            this.txtTrabFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeric_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Trabalho Final";
            // 
            // lblNotaFinal
            // 
            this.lblNotaFinal.AutoSize = true;
            this.lblNotaFinal.Location = new System.Drawing.Point(87, 218);
            this.lblNotaFinal.Name = "lblNotaFinal";
            this.lblNotaFinal.Size = new System.Drawing.Size(35, 13);
            this.lblNotaFinal.TabIndex = 6;
            this.lblNotaFinal.Text = "label6";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(114, 249);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmNotaFinal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 281);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblNotaFinal);
            this.Controls.Add(this.txtTrabFinal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.groupBox1);
            this.MaximumSize = new System.Drawing.Size(316, 320);
            this.MinimumSize = new System.Drawing.Size(316, 240);
            this.Name = "frmNotaFinal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nota Final";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSegTeste;
        private System.Windows.Forms.TextBox txtPrimTeste;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSegTrabPra;
        private System.Windows.Forms.TextBox txtPrimTrabPra;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTrabFinal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblNotaFinal;
        private System.Windows.Forms.Button btnLimpar;
    }
}