﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace PrimeiraApp
{
    public partial class frmQueHorasSao : Form
    {
        public frmQueHorasSao()
        {
            InitializeComponent();
        }

        private void bttAtualizar_Click(object sender, EventArgs e)
        {
            if (rbttAuto.Checked == true)
            {
                Tempo.Enabled = true;
                Tempo_Tick(null, null);
                bttAtualizar.Enabled = false;
            }
            else
            {
                Tempo.Enabled = false;
                Tempo_Tick(null, null);
            }
        }

        private void Tempo_Tick(object sender, EventArgs e)
        {
            DateTime data = DateTime.Now;

            barHora.Value = data.Hour;
            lblHora.Text = data.Hour.ToString();
            barMinuto.Value = data.Minute;
            lblMinuto.Text = data.Minute.ToString();
            barSegundo.Value = data.Second;
            lblSegundo.Text = data.Second.ToString();
        }

        private void rbttManual_CheckedChanged(object sender, EventArgs e)
        {
            bttAtualizar.Enabled = true;
        }

        

    }
}