﻿namespace PrimeiraApp
{
    partial class frmQueHorasSao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.barHora = new System.Windows.Forms.ProgressBar();
            this.barMinuto = new System.Windows.Forms.ProgressBar();
            this.barSegundo = new System.Windows.Forms.ProgressBar();
            this.rbttAuto = new System.Windows.Forms.RadioButton();
            this.rbttManual = new System.Windows.Forms.RadioButton();
            this.bttAtualizar = new System.Windows.Forms.Button();
            this.Tempo = new System.Windows.Forms.Timer(this.components);
            this.lblHora = new System.Windows.Forms.Label();
            this.lblMinuto = new System.Windows.Forms.Label();
            this.lblSegundo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // barHora
            // 
            this.barHora.Location = new System.Drawing.Point(46, 27);
            this.barHora.Maximum = 23;
            this.barHora.Name = "barHora";
            this.barHora.Size = new System.Drawing.Size(364, 36);
            this.barHora.TabIndex = 0;
            // 
            // barMinuto
            // 
            this.barMinuto.Location = new System.Drawing.Point(46, 98);
            this.barMinuto.Maximum = 59;
            this.barMinuto.Name = "barMinuto";
            this.barMinuto.Size = new System.Drawing.Size(364, 36);
            this.barMinuto.TabIndex = 1;
            // 
            // barSegundo
            // 
            this.barSegundo.Location = new System.Drawing.Point(46, 165);
            this.barSegundo.Maximum = 59;
            this.barSegundo.Name = "barSegundo";
            this.barSegundo.Size = new System.Drawing.Size(364, 36);
            this.barSegundo.TabIndex = 2;
            // 
            // rbttAuto
            // 
            this.rbttAuto.AutoSize = true;
            this.rbttAuto.Location = new System.Drawing.Point(46, 241);
            this.rbttAuto.Name = "rbttAuto";
            this.rbttAuto.Size = new System.Drawing.Size(78, 17);
            this.rbttAuto.TabIndex = 3;
            this.rbttAuto.TabStop = true;
            this.rbttAuto.Text = "Automatico";
            this.rbttAuto.UseVisualStyleBackColor = true;
            // 
            // rbttManual
            // 
            this.rbttManual.AutoSize = true;
            this.rbttManual.Location = new System.Drawing.Point(46, 264);
            this.rbttManual.Name = "rbttManual";
            this.rbttManual.Size = new System.Drawing.Size(60, 17);
            this.rbttManual.TabIndex = 4;
            this.rbttManual.TabStop = true;
            this.rbttManual.Text = "Manual";
            this.rbttManual.UseVisualStyleBackColor = true;
            this.rbttManual.CheckedChanged += new System.EventHandler(this.rbttManual_CheckedChanged);
            // 
            // bttAtualizar
            // 
            this.bttAtualizar.Location = new System.Drawing.Point(207, 235);
            this.bttAtualizar.Name = "bttAtualizar";
            this.bttAtualizar.Size = new System.Drawing.Size(203, 46);
            this.bttAtualizar.TabIndex = 5;
            this.bttAtualizar.Text = "Atualizar";
            this.bttAtualizar.UseVisualStyleBackColor = true;
            this.bttAtualizar.Click += new System.EventHandler(this.bttAtualizar_Click);
            // 
            // Tempo
            // 
            this.Tempo.Interval = 1000;
            this.Tempo.Tick += new System.EventHandler(this.Tempo_Tick);
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Location = new System.Drawing.Point(204, 9);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(30, 13);
            this.lblHora.TabIndex = 6;
            this.lblHora.Text = "Hora";
            // 
            // lblMinuto
            // 
            this.lblMinuto.AutoSize = true;
            this.lblMinuto.Location = new System.Drawing.Point(204, 82);
            this.lblMinuto.Name = "lblMinuto";
            this.lblMinuto.Size = new System.Drawing.Size(39, 13);
            this.lblMinuto.TabIndex = 7;
            this.lblMinuto.Text = "Minuto";
            // 
            // lblSegundo
            // 
            this.lblSegundo.AutoSize = true;
            this.lblSegundo.Location = new System.Drawing.Point(204, 149);
            this.lblSegundo.Name = "lblSegundo";
            this.lblSegundo.Size = new System.Drawing.Size(50, 13);
            this.lblSegundo.TabIndex = 8;
            this.lblSegundo.Text = "Segundo";
            // 
            // frmQueHorasSao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 299);
            this.Controls.Add(this.lblSegundo);
            this.Controls.Add(this.lblMinuto);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.bttAtualizar);
            this.Controls.Add(this.rbttManual);
            this.Controls.Add(this.rbttAuto);
            this.Controls.Add(this.barSegundo);
            this.Controls.Add(this.barMinuto);
            this.Controls.Add(this.barHora);
            this.Name = "frmQueHorasSao";
            this.Text = "frmQueHorasSao";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar barHora;
        private System.Windows.Forms.ProgressBar barMinuto;
        private System.Windows.Forms.ProgressBar barSegundo;
        private System.Windows.Forms.RadioButton rbttAuto;
        private System.Windows.Forms.RadioButton rbttManual;
        private System.Windows.Forms.Button bttAtualizar;
        private System.Windows.Forms.Timer Tempo;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblMinuto;
        private System.Windows.Forms.Label lblSegundo;
    }
}