﻿namespace PrimeiraApp
{
    partial class frmCumprimentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCumprimentos));
            this.textModo = new System.Windows.Forms.TextBox();
            this.textNome = new System.Windows.Forms.TextBox();
            this.btnClique = new System.Windows.Forms.Button();
            this.labelMostra = new System.Windows.Forms.Label();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textModo
            // 
            this.textModo.Location = new System.Drawing.Point(12, 12);
            this.textModo.Name = "textModo";
            this.textModo.Size = new System.Drawing.Size(100, 20);
            this.textModo.TabIndex = 0;
            // 
            // textNome
            // 
            this.textNome.Location = new System.Drawing.Point(12, 39);
            this.textNome.Name = "textNome";
            this.textNome.Size = new System.Drawing.Size(100, 20);
            this.textNome.TabIndex = 1;
            // 
            // btnClique
            // 
            this.btnClique.Location = new System.Drawing.Point(170, 37);
            this.btnClique.Name = "btnClique";
            this.btnClique.Size = new System.Drawing.Size(75, 23);
            this.btnClique.TabIndex = 2;
            this.btnClique.Text = "Clique";
            this.btnClique.UseVisualStyleBackColor = true;
            this.btnClique.Click += new System.EventHandler(this.btnClique_Click);
            // 
            // labelMostra
            // 
            this.labelMostra.AutoSize = true;
            this.labelMostra.Location = new System.Drawing.Point(13, 106);
            this.labelMostra.Name = "labelMostra";
            this.labelMostra.Size = new System.Drawing.Size(35, 13);
            this.labelMostra.TabIndex = 3;
            this.labelMostra.Text = "label1";
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(170, 106);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(75, 23);
            this.buttonLimpar.TabIndex = 4;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.buttonLimpar_Click);
            // 
            // frmCumprimentos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 151);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.labelMostra);
            this.Controls.Add(this.btnClique);
            this.Controls.Add(this.textNome);
            this.Controls.Add(this.textModo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(291, 190);
            this.MinimumSize = new System.Drawing.Size(291, 110);
            this.Name = "frmCumprimentos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cumprimentos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textModo;
        private System.Windows.Forms.TextBox textNome;
        private System.Windows.Forms.Button btnClique;
        private System.Windows.Forms.Label labelMostra;
        private System.Windows.Forms.Button buttonLimpar;
    }
}