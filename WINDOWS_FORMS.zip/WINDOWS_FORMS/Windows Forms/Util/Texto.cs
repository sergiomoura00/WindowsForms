﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util.Texto
{
    public static class Exercicio5
    {
        public static string NomeReduzido(string nomeCompleto)
        {
            string[] nome = CortaNome(nomeCompleto);
            return string.Format("{0} {1}", nome[0], nome[1]);
        }
        public static string EmailCompleto(string nomeCompleto)
        {
            string[] nome = CortaNome(nomeCompleto);
            return string.Format("{0}.{1}@xpto.pt"
                , nome[0].ToLower(), nome[1].ToLower());
        }
        public static string EmailReduzido(string nomeCompleto)
        {
            string[] nome = CortaNome(nomeCompleto);
            return string.Format("{0}{1}@xpto.pt"
                , (nome[0].ToLower())[0], nome[1].ToLower());
        }
        private static string[] CortaNome(string nomeCompleto)
        {
            //string[] arr1 = nomeCompleto.Split(' ');
            //string[] arr2 = { arr1[0], arr1[arr1.Length - 1] };
            //return arr2;
            string[] retorno = new string[2];
            string[] splitted = nomeCompleto.Split(' ');
            retorno[0] = splitted[0];
            retorno[1] = splitted[splitted.Length - 1];
            return retorno;
        }
    }
    public static class Exercicio10
    {
        public static string SubstituiTemp(string frase)
        {
            Dictionary<string, string> dicionario =
                new Dictionary<string, string>();
            dicionario.Add("ã","a");
            dicionario.Add("á", "a");
            dicionario.Add("à", "a");
            dicionario.Add("â", "a");
            dicionario.Add("é", "e");
            dicionario.Add("ê", "e");
            dicionario.Add("õ", "o");
            dicionario.Add("ó", "o");
            dicionario.Add("ô", "o");
            dicionario.Add("ç", "c");

            string novaFrase = "";

            foreach(char c in frase)
            {
                if (dicionario.ContainsKey(c.ToString()))
                    novaFrase += dicionario[c.ToString()];
                else
                    novaFrase += c.ToString();
            }

            return novaFrase;
        }
        public static string Substitui(string frase)
        {
            Dictionary<string, string> letras =
                new Dictionary<string, string>()
                {
                    { "ã","a"},
                    { "á","a"},
                    { "à","a"},
                    { "â","a"},
                    { "é","e"},
                    { "ê","e"},
                    { "ó","o"},
                    { "ô","o"},
                    { "õ","o"},
                    { "ç","c"}
                };
            char[] novaFrase = new char[frase.Length];
            for (int i = 0; i < frase.Length; i++)
            {
                if (letras.ContainsKey(frase[i].ToString()))
                    novaFrase[i] = (letras[frase[i].ToString()])[0];
                else
                    novaFrase[i] = frase[i];
            }
            return new string(novaFrase);
        }
        public static string RetiraEspacos(string frase)
        {
            //System.Text.RegularExpressions.
            //       Regex.Match(frase, "[a-zA-Z0-9]+@[a-z]{2}.[5-9]{2,4}");
            return System.Text.RegularExpressions.
                Regex.Replace(
                    frase, " {2,}", " "
                    );
        }
    }
    public class Pessoa
    {
        public int MyProperty { get; set; }
        public string MyProperty2 { get; set; }
    }
}
