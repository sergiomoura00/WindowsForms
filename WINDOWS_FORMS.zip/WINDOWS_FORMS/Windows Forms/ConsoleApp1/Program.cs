﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    class Program
    {
        static void Main(string[] args)
        {
            //CONSTRUÇÃO DE OBJECTO TRADICIONAL
            //MinhasClasses.GeneroLivro g = new MinhasClasses.GeneroLivro();
            //g.Descricao = "abc";

            //CONSTRUÇÃO DE OBJECTO INLINE
            //MinhasClasses.GeneroLivro G =
            //    new MinhasClasses.GeneroLivro() { Descricao = "abc" };

            //MinhasClasses.Livro livro =
            //    new MinhasClasses.Livro("", "",
            //    new MinhasClasses.GeneroLivro() { Descricao = "xpto" },
            //    DateTime.Now,
            //    new MinhasClasses.Editora() { Nome = "abc" }
            //    );
            //Console.WriteLine(livro.ImprimeDados());


            //Console.Write("Escreva um nome: ");
            //string nome = Console.ReadLine();
            //string nomeReduzido = Util.Texto.Exercicio5.EmailCompleto(nome);
            //Console.WriteLine("O seu nome reduzido:");
            //Console.WriteLine(nomeReduzido);

            //int[] array = { 3, 5, 7, 1, 10, 2, 23, 1, 9 };

            //int numAprocurar = 9;
            //bool encontrei = false;

            //for(int i =0; i<array.Length;i++)
            //{
            //    if (array[i] == numAprocurar)
            //        encontrei = true;
            //}
            //foreach(int i in array)
            //{
            //    if (i == numAprocurar)
            //        encontrei = true;
            //}

            //int x = array.FirstOrDefault(XPTO => XPTO == numAprocurar);
            //if (x > 0)
            //    encontrei = true;

            //encontrei = array.FirstOrDefault(XPTO => XPTO == numAprocurar) > 0 ?
            //    true : false;


            //Teste[] arrayteste = new Teste[3];
            //arrayteste[0] = new Teste();
            //arrayteste[1] = new Teste();
            //arrayteste[2] = new Teste();

            //arrayteste[0].Id = 100;
            //arrayteste[0].Descricao = "xpto";
            //arrayteste[1].Id = 200;
            //arrayteste[1].Descricao = "abc";
            //arrayteste[2].Id = 300;
            //arrayteste[2].Descricao = "asasd";

            //Teste xx =
            //arrayteste.FirstOrDefault(obj => obj.Descricao == "abc" );

            //Console.WriteLine(xx.Descricao+"|"+xx.Id);
            //Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);

            //xx.Id = 999;

            //Console.WriteLine(xx.Descricao + "|" + xx.Id);
            //Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);

            //arrayteste[1].Descricao = "Antonio";

            //Console.WriteLine(xx.Descricao + "|" + xx.Id);
            //Console.WriteLine(arrayteste[1].Descricao + "|" + arrayteste[1].Id);


            ////OPERADOR TERNÁRIO 
            ////Utilização do símbolo ?
            ////VALOR = CONDIÇÃO ? SE VERDADE : SE MENTIRA;

            ////int a = xx.Id == 999 ? -1 : 0;
            //xx.Id = 0;
            //int a = xx.Id == 999 ?
            //    (arrayteste.Length > 3 ? 1: 2) : 3;
            //int[] numeros = new int[5];
            //for (int i = 0; i <= 4; i++)
            //{
            //    bool flag = true;
            //    while (flag)
            //    {
            //        Console.Write("número: ");
            //        int num = int.Parse(Console.ReadLine());
            //        if (num <= 50 && num > 0)
            //        {
            //            numeros[i] = num;
            //            flag = false;
            //        }
            //    }
            //}
            //int[] estrelas = new int[2];
            //for (int i = 0; i <= 1; i++)
            //{
            //    bool flag = true;
            //    while (flag)
            //    {
            //        Console.Write("estrela: ");
            //        int num = int.Parse(Console.ReadLine());
            //        if (num <= 12 && num > 0)
            //        {
            //            estrelas[i] = num;
            //            flag = false;
            //        }
            //    }
            //}
            //Console.Write("Chave inserida: ");
            //for (int i = 0; i <= 4; i++)
            //{
            //    Console.Write(numeros[i]);
            //    if (i != 4)
            //        Console.Write("-");
            //}
            //Console.Write("+");
            //for (int i = 0; i <= 1; i++)
            //{
            //    Console.Write(numeros[i]);
            //    if (i != 1)
            //        Console.Write("-");
            //}

            //System.IO.StreamReader sr =
            //            new System.IO.StreamReader("chaves.txt");
            //string texto, lastId = "";
            //while ((texto = sr.ReadLine()) != null)
            //{
            //    string[] conteudo = texto.Split('|');
            //    if (conteudo.Length == 3)
            //    {
            //        string idChave = conteudo[0];
            //        string[] _numeros = conteudo[1].Split('-');
            //        string[] _estrelas = conteudo[2].Split('-');

            //        string output = "Chave com o id " + idChave + "\nNúmeros:\n";
            //        foreach (string numero in _numeros)
            //            output += numero + "\n";
            //        output += "Estrelas:\n";
            //        foreach (string estrela in _estrelas)
            //            output += estrela + "\n";
            //        output += "*******************\n";
            //        Console.WriteLine(output);

            //        lastId = idChave;
            //    }
            //}

            //sr.Close();

            //System.IO.StreamWriter sw =
            //                new System.IO.StreamWriter("chaves.txt", true);
            //string escrever = (int.Parse(lastId) + 1).ToString();
            //escrever += "|";
            //for (int i = 0; i <= 4; i++)
            //{
            //    escrever += numeros[i];
            //    if (i != 4)
            //        escrever += "-";
            //}
            //escrever += "|";
            //for (int i = 0; i <= 1; i++)
            //{
            //    escrever += numeros[i];
            //    if (i != 1)
            //        escrever += "-";
            //}
            //sw.WriteLine(escrever);
            //sw.Close();




            Console.Read();







        }
    }


    public class Teste
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}
