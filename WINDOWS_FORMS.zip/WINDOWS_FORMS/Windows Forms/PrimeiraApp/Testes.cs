﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MinhasClasses;

namespace PrimeiraApp
{
    public partial class Testes : Form
    {
        public Testes()
        {
            InitializeComponent();
            lstBoxEditoras.DisplayMember = "Nome";
            lstBoxAutores.DisplayMember = "Nome";
        }

        private void btnNovaEditora_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovaEditora.Text))
            {
                Editora editora = new Editora()
                {
                    Nome = txtNovaEditora.Text
                };

                lstBoxEditoras.Items.Add(editora);
                txtNovaEditora.Text = "";
            }
        }

        private void btnNovoAutor_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovoAutor.Text))
            {
                if (lstBoxEditoras.SelectedItems.Count > 0)
                {
                    List<Editora> lista = new List<Editora>();
                    foreach(Editora editora in lstBoxEditoras.SelectedItems)
                    {
                        lista.Add(editora);
                    }

                    Autor autor = new Autor()
                    {
                        Nome = txtNovoAutor.Text,
                        EditorasUsadas = lista
                    };

                    lstBoxAutores.Items.Add(autor);
                    txtNovoAutor.Text = string.Empty;
                    lstBoxEditoras.SelectedIndex = -1;
                }
            }
        }

        private void lstBoxAutores_DoubleClick(object sender, EventArgs e)
        {
            Autor x = (Autor)lstBoxAutores.SelectedItems[0];
            string editoras = "";
            foreach (Editora y in x.EditorasUsadas)
            {
                editoras += y.Nome + "\n";
            }
            MessageBox.Show(string.Format("Nome do autor: {0}\nId do Autor: {1}\nEditoras usadas:\n{2}", x.Nome, x.Id, editoras));
        }
    }
}
