﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeiraApp
{
    public static class Auxiliares
    {
        public static class Conversores
        {
            public static double ConverterMoeda(double valor, string Moeda)
            {
                switch (Moeda)
                {
                    case "Dollar":
                        return Math.Round((valor * Properties.Settings.Default.moeda_dollar), 2);
                        break;
                    case "Libra":
                        return Math.Round((valor * Properties.Settings.Default.moeda_libra), 2);
                        break;
                    case "Iéne":
                        return Math.Round((valor * Properties.Settings.Default.moeda_iene), 2);
                        break;
                    case "SEK":
                        return Math.Round((valor * Properties.Settings.Default.moeda_sek), 2);
                        break;
                    default:
                        return 0.0;
                        break;
                }
            }
        }
    }
}
