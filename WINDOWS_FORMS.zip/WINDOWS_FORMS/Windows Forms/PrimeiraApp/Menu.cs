﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void mnFicheiroSair_Click(object sender, EventArgs e)
        {
            DialogResult resultado =
            MessageBox.Show(
                "Tem a certeza que quer sair?",
                "A encerrar...",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);

            switch(resultado)
            {
                case DialogResult.Yes:
                case DialogResult.OK:
                    Application.Exit();
                    break;

            }

            if (resultado == DialogResult.Yes)
                Application.Exit();

        }

        private void mnExemplos_Click(object sender, EventArgs e)
        {

        }

        #region Menu Exercícios

        private void mnExerCump_Click(object sender, EventArgs e)
        {
            frmCumprimentos f = this.MdiChildren.FirstOrDefault
                (xpto => xpto.GetType() == typeof(frmCumprimentos))
                as frmCumprimentos;

            if (f == null)
            {
                f = new frmCumprimentos();
                f.MdiParent = this;
            }
            f.Show();
        }

        private void mnExerFahr_Click(object sender, EventArgs e)
        {
            frmFahrenheit f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmFahrenheit)) as frmFahrenheit;

            if (f == null)
            {
                f = new frmFahrenheit();
                f.MdiParent = this;
            }
            f.Show();
        }

        private void mnExerCalcNota_Click(object sender, EventArgs e)
        {
            frmNotaFinal f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmNotaFinal)) as frmNotaFinal;

            if (f == null)
            {
                f = new frmNotaFinal();
                f.MdiParent = this;
            }
            f.Show();
        }

        private void mnExerNomeEmail_Click(object sender, EventArgs e)
        {
            frmNomeEmail f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmNomeEmail)) as frmNomeEmail;

            if (f == null)
            {
                f = new frmNomeEmail();
                f.MdiParent = this;
            }
            f.Show();
        }

        private void mnExerQueHorasSao_Click(object sender, EventArgs e)
        {
            frmQueHorasSao f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmQueHorasSao)) as frmQueHorasSao;

            if (f == null)
            {
                f = new frmQueHorasSao();
                f.MdiParent = this;
            }
            f.Show();
        }

        private void mnExerQuantoTempoPassou_Click(object sender, EventArgs e)
        {
            frmQuantoTempoPassou f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmQuantoTempoPassou)) as frmQuantoTempoPassou;

            if (f == null)
            {
                f = new frmQuantoTempoPassou();
                f.MdiParent = this;
            }
            f.Show();
        }

        //private void mnExerCambioRB_Click(object sender, EventArgs e)
        //{
        //    frmCambioRadioButton f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmCambioRadioButton)) as frmCambioRadioButton;

        //    if (f == null)
        //    {
        //        f = new frmCambioRadioButton();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerCambioCHK_Click(object sender, EventArgs e)
        //{
        //    frmCambioCheckBox f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmCambioCheckBox)) as frmCambioCheckBox;

        //    if (f == null)
        //    {
        //        f = new frmCambioCheckBox();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerCambioCombo_Click(object sender, EventArgs e)
        //{
        //    frmCambioDropDown f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmCambioDropDown)) as frmCambioDropDown;

        //    if (f == null)
        //    {
        //        f = new frmCambioDropDown();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerTabuada_Click(object sender, EventArgs e)
        //{
        //    frmTabuada f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmTabuada)) as frmTabuada;

        //    if (f == null)
        //    {
        //        f = new frmTabuada();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerArvore_Click(object sender, EventArgs e)
        //{
        //    frmArvore f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmArvore)) as frmArvore;

        //    if (f == null)
        //    {
        //        f = new frmArvore();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerHobbies_Click(object sender, EventArgs e)
        //{
        //    frmHobbies f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmHobbies)) as frmHobbies;

        //    if (f == null)
        //    {
        //        f = new frmHobbies();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        private void mnExerLimpaTexto_Click(object sender, EventArgs e)
        {
            frmLimpaTexto f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmLimpaTexto)) as frmLimpaTexto;

            if (f == null)
            {
                f = new frmLimpaTexto();
                f.MdiParent = this;
            }
            f.Show();
        }

        //private void mnExerMeusHobbies_Click(object sender, EventArgs e)
        //{
        //    frmMeusHobbies f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmMeusHobbies)) as frmMeusHobbies;

        //    if (f == null)
        //    {
        //        f = new frmMeusHobbies();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        //private void mnExerFicheiros_Click(object sender, EventArgs e)
        //{
        //    frmFicheiros f = this.MdiChildren.FirstOrDefault(obj => obj.GetType() == typeof(frmFicheiros)) as frmFicheiros;

        //    if (f == null)
        //    {
        //        f = new frmFicheiros();
        //        f.MdiParent = this;
        //    }
        //    f.Show();
        //}

        #endregion

        private void mnJanelaCasc_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void mnJanelaHor_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnJanelaVert_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }
    }
}
