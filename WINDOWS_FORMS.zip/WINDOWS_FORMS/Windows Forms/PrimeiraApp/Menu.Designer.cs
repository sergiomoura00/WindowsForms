﻿namespace PrimeiraApp
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ficheiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnFicheiroSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExemplos = new System.Windows.Forms.ToolStripMenuItem();
            this.exercíciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerCump = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerFahr = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerCalcNota = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerNomeEmail = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerQueHorasSao = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerQuantoTempoPassou = new System.Windows.Forms.ToolStripMenuItem();
            this.cambioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerCambioRB = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerCambioCHK = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerCambioCombo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerTabuada = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerArvore = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerLimpaTexto = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerHobbies = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerMeusHobbies = new System.Windows.Forms.ToolStripMenuItem();
            this.janelaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaCasc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaHor = new System.Windows.Forms.ToolStripMenuItem();
            this.mnJanelaVert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnExerFicheiros = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheiroToolStripMenuItem,
            this.mnExemplos,
            this.exercíciosToolStripMenuItem,
            this.janelaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(609, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ficheiroToolStripMenuItem
            // 
            this.ficheiroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnFicheiroSair});
            this.ficheiroToolStripMenuItem.Name = "ficheiroToolStripMenuItem";
            this.ficheiroToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ficheiroToolStripMenuItem.Text = "Ficheiro";
            // 
            // mnFicheiroSair
            // 
            this.mnFicheiroSair.Name = "mnFicheiroSair";
            this.mnFicheiroSair.Size = new System.Drawing.Size(180, 22);
            this.mnFicheiroSair.Text = "Sair";
            this.mnFicheiroSair.Click += new System.EventHandler(this.mnFicheiroSair_Click);
            // 
            // mnExemplos
            // 
            this.mnExemplos.Name = "mnExemplos";
            this.mnExemplos.Size = new System.Drawing.Size(69, 20);
            this.mnExemplos.Text = "Exemplos";
            this.mnExemplos.Click += new System.EventHandler(this.mnExemplos_Click);
            // 
            // exercíciosToolStripMenuItem
            // 
            this.exercíciosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnExerCump,
            this.mnExerFahr,
            this.mnExerCalcNota,
            this.mnExerNomeEmail,
            this.mnExerQueHorasSao,
            this.mnExerQuantoTempoPassou,
            this.cambioToolStripMenuItem,
            this.mnExerTabuada,
            this.mnExerArvore,
            this.mnExerLimpaTexto,
            this.mnExerHobbies,
            this.mnExerMeusHobbies,
            this.mnExerFicheiros});
            this.exercíciosToolStripMenuItem.Name = "exercíciosToolStripMenuItem";
            this.exercíciosToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.exercíciosToolStripMenuItem.Text = "Exercícios";
            // 
            // mnExerCump
            // 
            this.mnExerCump.Name = "mnExerCump";
            this.mnExerCump.Size = new System.Drawing.Size(194, 22);
            this.mnExerCump.Text = "Cumprimentos";
            this.mnExerCump.Click += new System.EventHandler(this.mnExerCump_Click);
            // 
            // mnExerFahr
            // 
            this.mnExerFahr.Name = "mnExerFahr";
            this.mnExerFahr.Size = new System.Drawing.Size(194, 22);
            this.mnExerFahr.Text = "Fahrenheit";
            this.mnExerFahr.Click += new System.EventHandler(this.mnExerFahr_Click);
            // 
            // mnExerCalcNota
            // 
            this.mnExerCalcNota.Name = "mnExerCalcNota";
            this.mnExerCalcNota.Size = new System.Drawing.Size(194, 22);
            this.mnExerCalcNota.Text = "Calcular Nota";
            this.mnExerCalcNota.Click += new System.EventHandler(this.mnExerCalcNota_Click);
            // 
            // mnExerNomeEmail
            // 
            this.mnExerNomeEmail.Name = "mnExerNomeEmail";
            this.mnExerNomeEmail.Size = new System.Drawing.Size(194, 22);
            this.mnExerNomeEmail.Text = "Nome e Email";
            this.mnExerNomeEmail.Click += new System.EventHandler(this.mnExerNomeEmail_Click);
            // 
            // mnExerQueHorasSao
            // 
            this.mnExerQueHorasSao.Name = "mnExerQueHorasSao";
            this.mnExerQueHorasSao.Size = new System.Drawing.Size(194, 22);
            this.mnExerQueHorasSao.Text = "Que Horas são";
            this.mnExerQueHorasSao.Click += new System.EventHandler(this.mnExerQueHorasSao_Click);
            // 
            // mnExerQuantoTempoPassou
            // 
            this.mnExerQuantoTempoPassou.Name = "mnExerQuantoTempoPassou";
            this.mnExerQuantoTempoPassou.Size = new System.Drawing.Size(194, 22);
            this.mnExerQuantoTempoPassou.Text = "Quanto Tempo Passou";
            this.mnExerQuantoTempoPassou.Click += new System.EventHandler(this.mnExerQuantoTempoPassou_Click);
            // 
            // cambioToolStripMenuItem
            // 
            this.cambioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnExerCambioRB,
            this.mnExerCambioCHK,
            this.mnExerCambioCombo});
            this.cambioToolStripMenuItem.Name = "cambioToolStripMenuItem";
            this.cambioToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.cambioToolStripMenuItem.Text = "Cambio";
            
            // 
            // mnExerLimpaTexto
            // 
            this.mnExerLimpaTexto.Name = "mnExerLimpaTexto";
            this.mnExerLimpaTexto.Size = new System.Drawing.Size(194, 22);
            this.mnExerLimpaTexto.Text = "Limpa Text Boxes";
            this.mnExerLimpaTexto.Click += new System.EventHandler(this.mnExerLimpaTexto_Click);
       
            // 
            // janelaToolStripMenuItem
            // 
            this.janelaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnJanelaCasc,
            this.mnJanelaHor,
            this.mnJanelaVert});
            this.janelaToolStripMenuItem.Name = "janelaToolStripMenuItem";
            this.janelaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.janelaToolStripMenuItem.Text = "Janela";
            // 
            // mnJanelaCasc
            // 
            this.mnJanelaCasc.Name = "mnJanelaCasc";
            this.mnJanelaCasc.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaCasc.Text = "Cascata";
            this.mnJanelaCasc.Click += new System.EventHandler(this.mnJanelaCasc_Click);
            // 
            // mnJanelaHor
            // 
            this.mnJanelaHor.Name = "mnJanelaHor";
            this.mnJanelaHor.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaHor.Text = "Horizontal";
            this.mnJanelaHor.Click += new System.EventHandler(this.mnJanelaHor_Click);
            // 
            // mnJanelaVert
            // 
            this.mnJanelaVert.Name = "mnJanelaVert";
            this.mnJanelaVert.Size = new System.Drawing.Size(129, 22);
            this.mnJanelaVert.Text = "Vertical";
            this.mnJanelaVert.Click += new System.EventHandler(this.mnJanelaVert_Click);
          
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 496);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.Text = "Menu";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ficheiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnFicheiroSair;
        private System.Windows.Forms.ToolStripMenuItem mnExemplos;
        private System.Windows.Forms.ToolStripMenuItem exercíciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnExerCump;
        private System.Windows.Forms.ToolStripMenuItem mnExerFahr;
        private System.Windows.Forms.ToolStripMenuItem mnExerCalcNota;
        private System.Windows.Forms.ToolStripMenuItem janelaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaCasc;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaHor;
        private System.Windows.Forms.ToolStripMenuItem mnJanelaVert;
        private System.Windows.Forms.ToolStripMenuItem mnExerNomeEmail;
        private System.Windows.Forms.ToolStripMenuItem mnExerQueHorasSao;
        private System.Windows.Forms.ToolStripMenuItem mnExerQuantoTempoPassou;
        private System.Windows.Forms.ToolStripMenuItem cambioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnExerCambioRB;
        private System.Windows.Forms.ToolStripMenuItem mnExerCambioCHK;
        private System.Windows.Forms.ToolStripMenuItem mnExerCambioCombo;
        private System.Windows.Forms.ToolStripMenuItem mnExerTabuada;
        private System.Windows.Forms.ToolStripMenuItem mnExerArvore;
        private System.Windows.Forms.ToolStripMenuItem mnExerLimpaTexto;
        private System.Windows.Forms.ToolStripMenuItem mnExerHobbies;
        private System.Windows.Forms.ToolStripMenuItem mnExerMeusHobbies;
        private System.Windows.Forms.ToolStripMenuItem mnExerFicheiros;
    }
}