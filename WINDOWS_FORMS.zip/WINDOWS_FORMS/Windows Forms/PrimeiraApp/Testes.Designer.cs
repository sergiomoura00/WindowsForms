﻿namespace PrimeiraApp
{
    partial class Testes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNovaEditora = new System.Windows.Forms.TextBox();
            this.btnNovaEditora = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstBoxEditoras = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtNovoAutor = new System.Windows.Forms.TextBox();
            this.btnNovoAutor = new System.Windows.Forms.Button();
            this.lstBoxAutores = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNovaEditora
            // 
            this.txtNovaEditora.Location = new System.Drawing.Point(6, 35);
            this.txtNovaEditora.Name = "txtNovaEditora";
            this.txtNovaEditora.Size = new System.Drawing.Size(139, 20);
            this.txtNovaEditora.TabIndex = 0;
            // 
            // btnNovaEditora
            // 
            this.btnNovaEditora.Location = new System.Drawing.Point(151, 33);
            this.btnNovaEditora.Name = "btnNovaEditora";
            this.btnNovaEditora.Size = new System.Drawing.Size(75, 23);
            this.btnNovaEditora.TabIndex = 1;
            this.btnNovaEditora.Text = "Criar";
            this.btnNovaEditora.UseVisualStyleBackColor = true;
            this.btnNovaEditora.Click += new System.EventHandler(this.btnNovaEditora_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstBoxEditoras);
            this.groupBox1.Controls.Add(this.btnNovaEditora);
            this.groupBox1.Controls.Add(this.txtNovaEditora);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 246);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Editoras";
            // 
            // lstBoxEditoras
            // 
            this.lstBoxEditoras.FormattingEnabled = true;
            this.lstBoxEditoras.Location = new System.Drawing.Point(7, 62);
            this.lstBoxEditoras.Name = "lstBoxEditoras";
            this.lstBoxEditoras.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstBoxEditoras.Size = new System.Drawing.Size(219, 173);
            this.lstBoxEditoras.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstBoxAutores);
            this.groupBox2.Controls.Add(this.btnNovoAutor);
            this.groupBox2.Controls.Add(this.txtNovoAutor);
            this.groupBox2.Location = new System.Drawing.Point(251, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(284, 176);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Autores";
            // 
            // txtNovoAutor
            // 
            this.txtNovoAutor.Location = new System.Drawing.Point(7, 34);
            this.txtNovoAutor.Name = "txtNovoAutor";
            this.txtNovoAutor.Size = new System.Drawing.Size(190, 20);
            this.txtNovoAutor.TabIndex = 0;
            // 
            // btnNovoAutor
            // 
            this.btnNovoAutor.Location = new System.Drawing.Point(203, 32);
            this.btnNovoAutor.Name = "btnNovoAutor";
            this.btnNovoAutor.Size = new System.Drawing.Size(75, 23);
            this.btnNovoAutor.TabIndex = 1;
            this.btnNovoAutor.Text = "Criar";
            this.btnNovoAutor.UseVisualStyleBackColor = true;
            this.btnNovoAutor.Click += new System.EventHandler(this.btnNovoAutor_Click);
            // 
            // lstBoxAutores
            // 
            this.lstBoxAutores.FormattingEnabled = true;
            this.lstBoxAutores.Location = new System.Drawing.Point(7, 61);
            this.lstBoxAutores.Name = "lstBoxAutores";
            this.lstBoxAutores.Size = new System.Drawing.Size(271, 108);
            this.lstBoxAutores.TabIndex = 2;
            this.lstBoxAutores.DoubleClick += new System.EventHandler(this.lstBoxAutores_DoubleClick);
            // 
            // Testes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 299);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Testes";
            this.Text = "Testes";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtNovaEditora;
        private System.Windows.Forms.Button btnNovaEditora;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstBoxEditoras;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstBoxAutores;
        private System.Windows.Forms.Button btnNovoAutor;
        private System.Windows.Forms.TextBox txtNovoAutor;
    }
}