﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmLimpaTexto : Form
    {
        public frmLimpaTexto()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            foreach (Control c in this.Controls)
                if (c.GetType() == typeof(TextBox))
                    c.Text = string.Empty;
        }
    }
}
