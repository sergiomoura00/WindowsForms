﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmQueHorasSao : Form
    {
        Timer tempo;
        public frmQueHorasSao()
        {
            InitializeComponent();

            pbHoras.Maximum = 23;
            pbMinutos.Maximum = 59;
            pbSegundos.Maximum = 59;

            tempo = new Timer();
            tempo.Tick += Tempo_Tick;
            tempo.Interval = 1000;
            tempo.Start();

            rbAuto.Checked = true;
        }

        private void Tempo_Tick(object sender, EventArgs e)
        {
            DateTime data = DateTime.Now;

            pbHoras.Value = data.Hour;
            lblHoras.Text = data.Hour.ToString();
            pbMinutos.Value = data.Minute;
            lblMinutos.Text = data.Minute.ToString();
            pbSegundos.Value = data.Second;
            lblSegundos.Text = data.Second.ToString();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Tempo_Tick(null, null);
        }

        private void rbGeral_CheckedChanged(object sender, EventArgs e)
        {
            if(rbAuto.Checked)
            {
                tempo.Start();
                btnAtualizar.Enabled = false;
            }
            else
            {
                tempo.Stop();
                btnAtualizar.Enabled = true;
            }
        }

        private void rbAuto_CheckedChanged(object sender, EventArgs e)
        {
            btnAtualizar.Enabled = !rbAuto.Checked;

            tempo.Start();
        }

        private void rbManual_CheckedChanged(object sender, EventArgs e)
        {
            btnAtualizar.Enabled = rbManual.Checked;

            tempo.Stop();
        }
    }
}
