﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinhasClasses
{
    public class GeneroLivro
    {
        private string _id;
        private string _descricao;

        public GeneroLivro()
        {
            this._id = Guid.NewGuid().ToString();
        }
        public GeneroLivro(string d) : this()
        {
            this.Descricao = d;
        }

        public string Id
        {
            get { return this._id; }
        }
        public string Descricao
        {
            get { return this._descricao; }
            set { this._descricao = value; }
        }

        public string ImprimeDados()
        {
            return string.Format("Id: {0} | Descrição: {1}", this.Id, this.Descricao);
        }
    }
}
