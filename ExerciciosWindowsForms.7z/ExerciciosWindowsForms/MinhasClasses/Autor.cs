﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinhasClasses
{
    public class Autor
    {
        /*
         * Aqui utilizamos auto-propriedades (Framework 4.5 e superior)
         * As auto-propriedades permitem colocar get e/ou set
         * da mesma forma que se utilizam atributos com propriedades
         * É possível colocar valores "default" numa auto-propriedade
         * Basta adicionar = valor depois das { }
         * */
        public string Id { get; }
        public string Nome { get; set; } = string.Empty;
        public List<Editora> EditorasUsadas { get; set; } = new List<Editora>();

        public Autor()
        {
            this.Id = Guid.NewGuid().ToString();
        }
        public Autor(string nome, List<Editora> lista) : this()
        {
            this.Nome = nome ?? string.Empty;
            this.EditorasUsadas = lista ?? new List<Editora>();
        }
    }

    //***********************************//
    //DEMOS NAS AULAS
    //C# 5.0 e C# inferior
    public class CLASSE_COM_ATRIBUTOS_E_PROPRIEDADES
    {
        //Atributos
        private int _id;
        private string _valor;

        //Propriedades
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Valor
        {
            get { return _valor; }
            set { _valor = value; }
        }

        //Construtores

        //Métodos

    }
    public class CLASSE_COM_AUTO_PROPRIEDADES
    {
        //Auto-propriedades
        public int Id { get; set; } = -1;
        public string Valor { get; } = "abc";

        public CLASSE_COM_AUTO_PROPRIEDADES()
        { }

        public CLASSE_COM_AUTO_PROPRIEDADES(int id) : this()
        { this.Id = id; }

        public CLASSE_COM_AUTO_PROPRIEDADES
            (string valor, int id) : this(id)
        { this.Valor = valor; }
    }












}
