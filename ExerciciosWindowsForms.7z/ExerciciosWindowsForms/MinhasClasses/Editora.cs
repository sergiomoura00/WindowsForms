﻿using System;

namespace MinhasClasses
{
    public class Editora
    {
        private string _id;
        private string _nome;

        public Editora()
        {
            this._id = Guid.NewGuid().ToString();
        }
        public Editora(string n) : this()
        {
            this.Nome = n;
        }

        public string Id
        {
            get { return this._id; }
            set { this._id = value; }
        }
        public string Nome
        {
            get { return this._nome; }
            set { this._nome = value; }
        }

        public string ImprimeDados()
        {
            return string.Format("Id: {0} | Nome: {1}", this.Id, this.Nome);
        }
    }
}
