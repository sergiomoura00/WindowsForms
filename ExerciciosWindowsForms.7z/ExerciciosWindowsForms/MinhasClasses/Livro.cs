﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinhasClasses
{
    public class Livro
    {
        #region Atributos
        private string _isbn;
        private string _titulo;
        private GeneroLivro _genero;
        private DateTime _dataPublicacao;
        private Editora _editora;
        #endregion

        #region Construtores
        private Livro()
        {
            this._isbn = string.Empty;
            this._titulo = string.Empty;
            this._dataPublicacao = new DateTime();
        }
        public Livro(string isbn,
            string titulo,
            GeneroLivro genero,
            DateTime dataPub,
            Editora editora) : this()
        {
            /*****************/
            //INICIALIZADOS NO CONSTRUTOR VAZIO
            if (!string.IsNullOrEmpty(isbn))
                this._isbn = isbn;
            if (!string.IsNullOrEmpty(titulo))
                this._titulo = titulo;
            if (dataPub != null)
                this._dataPublicacao = dataPub;

            /**********************/
            //VERIFICADOS COM O OPERADOR COALESCE
            this._genero = genero ?? new GeneroLivro();
            
            this._editora = editora ?? new Editora();
        }
        #endregion

        #region Propriedades
        public string Isbn
        {
            get { return _isbn; }
        }
        public string Titulo
        {
            get { return _titulo; }
        }
        public GeneroLivro GeneroLivro
        {
            get { return _genero; }
        }
        public DateTime DataPublicacao
        {
            get { return _dataPublicacao; }
        }
        public Editora Editora
        {
            get { return _editora; }
        }
        #endregion

        #region Métodos
        public string ImprimeDados()
        {
            return string.Format("Isbn:{0}|Titulo:{1}|Género:{2}|Data:{3}|Editora:{4}",
                this.Isbn, this.Titulo, this.GeneroLivro.Descricao, this.DataPublicacao.ToString("dd-MM-yyyy"), this.Editora.Nome);
        }
        #endregion
    }
}
