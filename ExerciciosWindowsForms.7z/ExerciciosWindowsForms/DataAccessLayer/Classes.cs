﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Data;
using System.Xml.Linq;
using System.Reflection;

namespace DataAccessLayer
{

    /// <summary>
    /// Classe que permite aceder à BD de Toponímia definida no Ex4.
    /// <para>Faz uso de um construtor estático para inicializar a conexão à BD.</para>
    /// <para>A localização da BD é definida pelo ficheiro "Configuration.xml" que deve acompanhar a DLL nos projectos onde esta for referenciada.</para>
    /// <para>A localização da BD deve ser indicada como caminho relativo ao projecto onde é utilizada. 
    /// Se o executável está numa pasta e a BD está numa sub-pasta "BaseDados" dentro da pasta do executável, o caminho no ficheiro deverá ser: "BaseDados\\NomeDaBD.mdb".</para>
    /// </summary>
    public class DAL_Toponimia
    {
        private static SqlConnection conexao;
        static DAL_Toponimia()
        {
            conexao = new SqlConnection(string.Format(@"Data Source=localhost\sqlexpress;Initial Catalog=Toponimia;Trusted_Connection=True;"));
        }
        #region CREATE
        /// <summary>
        /// Este método permite inserir um item na BD.
        /// <para>Apenas está optimizado para a BD de Toponímia a utilizar no exercício 4.</para>
        /// <para>O objecto passado por parâmetro deverá ser uma instância de qualquer objecto suportado com os valores a guardar. O objecto deve vir TODO preenchido.</para>
        /// <para>Objectos suportados: Arruamento, TipoArruamento, Freguesia, Concelho, Distrito.</para>
        /// <para>Devolve o número de linhas que foram afectadas pela query.</para>
        /// </summary>
        public static int InsereItem(object item)
        {
            if (conexao != null)
            {
                if (conexao.State != ConnectionState.Open)
                    conexao.Open();
                SqlCommand cmd = CriarCommand(GLOBALS.QueryType.INSERT,
                                    item,
                                    string.Empty,
                                    string.Empty,
                                    null);
                return cmd.ExecuteNonQuery();
            }
            else
                return -1;
        }
        #endregion
        #region READ
        /// <summary>
        /// Este método permite obter um item da BD.
        /// <para>Apenas está optimizado para a BD de Toponímia a utilizar no exercício 4.</para>
        /// <para>O primeiro parâmetro indica o Id do objecto a ler. 
        /// O segundo parâmetro é uma instância do tipo de objecto a ler (não precisa de ter valores). 
        /// O terceiro parâmetro é uma List&lt;string&gt; onde se passam os campos a serem preenchidos (List&lt;string&gt;(){ "Id", "Designacao",... }). Caso se pretendam todos os campos, passamos List&lt;string&gt;(){ "*" }.</para>
        /// <para>Objectos suportados: Arruamento, TipoArruamento, Freguesia, Concelho, Distrito.</para>
        /// <para>O retorno deste método é o objecto preenchido.</para>
        /// </summary>
        public static object ObterItemById(int Id, object item, List<string> campos_retorno)
        {
            if (conexao != null)
            {
                if (conexao.State != ConnectionState.Open)
                    conexao.Open();
                SqlCommand cmd = CriarCommand(GLOBALS.QueryType.SELECT,
                                    item,
                                    "[Id]=" + Id,
                                    string.Empty,
                                    campos_retorno);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    return InstanciaObjecto(item, reader, campos_retorno);
                }
            }

            return null;
        }
        /// <summary>
        /// Este método permite obter uma lista de items da BD.
        /// <para>Apenas está optimizado para a BD de Toponímia a utilizar no exercício 4.</para>
        /// <para>O primeiro parâmetro é uma instância do tipo de objecto a ler (não precisa de ter valores). 
        /// O segundo parâmetro é uma List&lt;string&gt; onde se passam os campos a serem preenchidos (List&lt;string&gt;(){ "Id", "Designacao",... }). Caso se pretendam todos os campos, passamos List&lt;string&gt;(){ "*" }.</para>
        /// <para>Objectos suportados: Arruamento, TipoArruamento, Freguesia, Concelho, Distrito.</para>
        /// <para>O retorno deste método é uma lista com todos os objectos preenchidos.</para>
        /// </summary>
        public static List<object> ObterListaItems(object item, List<string> campos_retorno)
        {
            if (conexao != null)
            {
                if (conexao.State != ConnectionState.Open)
                    conexao.Open();

                SqlCommand cmd = CriarCommand(GLOBALS.QueryType.SELECT,
                                    item,
                                    string.Empty,
                                    string.Empty,
                                    campos_retorno);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    return InstanciaListaObjectos(item, reader, campos_retorno);
                }
            }

            return null;
        }
        #endregion
        #region UPDATE
        /// <summary>
        /// Este método permite actualizar um item na BD.
        /// <para>Apenas está optimizado para a BD de Toponímia a utilizar no exercício 4.</para>
        /// <para>O objecto passado no primeiro parâmetro deverá ser uma instância de qualquer objecto suportado com os valores a actualizar.</para>
        /// <para>No segundo parâmetro deve ser passada a condição de WHERE.</para>
        /// <para>Exemplo de utilização para actualizar a Freguesia com o Id 2:</para>
        /// <para>ActualizarItem(new Freguesia(){ Designacao="Novo Nome", Concelho=new Concelho(){ Id=10 }}, "Id=2")</para>
        /// <para>Exemplo de utilização para actualizar Concelhos cujo Distrito seja o Id 9 e que comecem com a letra A:</para>
        /// <para>ActualizarItem(new Concelho(){ Designacao="Novo Nome", Distrito=new Distrito(){ Id=9 } }, "Distrito=9 AND Designacao like 'A%'")</para>
        /// <para>Objectos suportados: Arruamento, TipoArruamento, Freguesia, Concelho, Distrito.</para>
        /// <para>Devolve o número de linhas que foram afectadas pela query.</para>
        /// </summary>
        public static int ActualizarItem(object item, string where)
        {
            if (conexao != null)
            {
                if (conexao.State != ConnectionState.Open)
                    conexao.Open();
                SqlCommand cmd = CriarCommand(GLOBALS.QueryType.UPDATE,
                                    item,
                                    where,
                                    string.Empty,
                                    null);
                return cmd.ExecuteNonQuery();
            }
            else
                return -1;
        }
        #endregion
        #region DELETE
        /// <summary>
        /// Este método permite apagar um item na BD.
        /// <para>Apenas está optimizado para a BD de Toponímia a utilizar no exercício 4.</para>
        /// <para>O objecto passado no primeiro parâmetro deverá ser uma instância de qualquer objecto suportado. Não tem que ter valores preenchidos.</para>
        /// <para>No segundo parâmetro deve ser passada a condição de WHERE.</para>
        /// <para>Exemplo de utilização para apagar a Freguesia com o Id 2:</para>
        /// <para>ApagarItem(new Freguesia(), "Id=2")</para>
        /// <para>Exemplo de utilização para apagar Concelhos cujo Distrito seja o Id 9 e que comecem com a letra A:</para>
        /// <para>ApagarItem(new Concelho(), "Distrito=9 AND Designacao like 'A%'")</para>
        /// <para>Objectos suportados: Arruamento, TipoArruamento, Freguesia, Concelho, Distrito.</para>
        /// <para>Devolve o número de linhas que foram afectadas pela query.</para>
        /// </summary>
        public static int ApagarItem(object item, string where)
        {
            if (conexao != null)
            {
                if (conexao.State != ConnectionState.Open)
                    conexao.Open();
                SqlCommand cmd = CriarCommand(GLOBALS.QueryType.DELETE,
                                    item,
                                    where,
                                    string.Empty,
                                    null);
                return cmd.ExecuteNonQuery();
            }
            else
                return -1;
        }
        #endregion
        #region AUXILIARES
        private static SqlCommand CriarCommand(GLOBALS.QueryType queryType,
            object item,
            string where,
            string orderBy,
            List<string> campos_retorno)
        {
            string tabela = string.Empty;
            string[] campos = null;
            string[] valores = null;
            Dictionary<string, object> parameters = null;
            ObjectParser(item, out tabela, out campos, out valores, out parameters);
            if (!string.IsNullOrEmpty(tabela))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conexao;
                switch (queryType)
                {
                    case GLOBALS.QueryType.INSERT:
                        try
                        {
                            campos = campos.Where((val, idx) => idx != 0).ToArray();
                            valores = valores.Where((val, idx) => idx != 0).ToArray();
                            cmd.CommandText =
                                string.Format("{0} INTO {1} ({2}) VALUES ({3})",
                                Enum.GetName(typeof(GLOBALS.QueryType), queryType),
                                tabela,
                                string.Join(",", campos),
                                string.Join(",", valores));
                            if (parameters != null)
                            {
                                foreach (KeyValuePair<string, object> vals in parameters)
                                    cmd.Parameters.AddWithValue(vals.Key, vals.Value);
                            }
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                        break;
                    case GLOBALS.QueryType.SELECT:
                        try
                        {
                            campos = campos_retorno.ToArray();

                            cmd.CommandText =
                                string.Format("{0} {1} FROM {2} {3} {4}",
                                Enum.GetName(typeof(GLOBALS.QueryType), queryType),
                                string.Join(",", campos),
                                tabela,
                                string.IsNullOrEmpty(where) ? "" : "WHERE " + where,
                                string.IsNullOrEmpty(orderBy) ? "" : "ORDER BY " + orderBy);
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                        break;
                    case GLOBALS.QueryType.UPDATE:
                        try
                        {
                            campos = campos.Where((val, idx) => idx != 0).ToArray();
                            valores = valores.Where((val, idx) => idx != 0).ToArray();
                            string[] set = new string[campos.Length];
                            if (campos.Length == valores.Length)
                                for (int i = 0; i < campos.Length; i++)
                                    set[i] = (campos[i] + "=" + valores[i]);
                            else
                                return null;
                            cmd.CommandText =
                                string.Format("{0} {1} SET {2} {3}",
                                Enum.GetName(typeof(GLOBALS.QueryType), queryType),
                                tabela,
                                string.Join(",", set),
                                string.IsNullOrEmpty(where) ? "" : "WHERE " + where);
                            if (parameters != null)
                            {
                                foreach (KeyValuePair<string, object> vals in parameters)
                                    cmd.Parameters.AddWithValue(vals.Key, vals.Value);
                            }
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                        break;
                    case GLOBALS.QueryType.DELETE:
                        try
                        {
                            cmd.CommandText =
                                string.Format("{0} FROM {1} {2}",
                                Enum.GetName(typeof(GLOBALS.QueryType), queryType),
                                tabela,
                                string.IsNullOrEmpty(where) ? "" : "WHERE " + where);
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                        break;
                    default: return null;
                }
                return cmd;
            }
            else
                return null;
        }
        private static void ObjectParser(object item, out string tabela, out string[] campos, out string[] valores, out Dictionary<string, object> parameters)
        {
            if (item is Arruamento)
            {
                tabela = GLOBALS.Tabelas.TbArruamento;
                campos = GLOBALS.Tabelas.Campos.TbArruamento;
                valores = GLOBALS.Tabelas.Valores.TbArruamento;
                parameters = new Dictionary<string, object>();
                parameters.Add(valores[1], (item as Arruamento).Designacao);
                parameters.Add(valores[2], (item as Arruamento).TipoArruamento == null ? -1 : (item as Arruamento).TipoArruamento.Id);
                parameters.Add(valores[3], (item as Arruamento).Freguesia == null ? -1 : (item as Arruamento).Freguesia.Id);
                parameters.Add(valores[4], (item as Arruamento).Inicio == null ? -1 : (item as Arruamento).Inicio.Id);
                parameters.Add(valores[5], (item as Arruamento).Fim == null ? -1 : (item as Arruamento).Fim.Id);
                parameters.Add(valores[6], (item as Arruamento).Extensao);
                parameters.Add(valores[7], (item as Arruamento).Longitude);
                parameters.Add(valores[8], (item as Arruamento).Latitude);
            }
            else if (item is TipoArruamento)
            {
                tabela = GLOBALS.Tabelas.TbTipoArruamento;
                campos = GLOBALS.Tabelas.Campos.TbTipoArruamento;
                valores = GLOBALS.Tabelas.Valores.TbTipoArruamento;
                parameters = new Dictionary<string, object>();
                parameters.Add(valores[1], (item as TipoArruamento).Designacao);
            }
            else if (item is Freguesia)
            {
                tabela = GLOBALS.Tabelas.TbFreguesia;
                campos = GLOBALS.Tabelas.Campos.TbFreguesia;
                valores = GLOBALS.Tabelas.Valores.TbFreguesia;
                parameters = new Dictionary<string, object>();
                parameters.Add(valores[1], (item as Freguesia).Designacao);
                parameters.Add(valores[2], (item as Freguesia).Concelho == null ? -1 : (item as Freguesia).Concelho.Id);
            }
            else if (item is Concelho)
            {
                tabela = GLOBALS.Tabelas.TbConcelho;
                campos = GLOBALS.Tabelas.Campos.TbConcelho;
                valores = GLOBALS.Tabelas.Valores.TbConcelho;
                parameters = new Dictionary<string, object>();
                parameters.Add(valores[1], (item as Concelho).Designacao);
                parameters.Add(valores[2], (item as Concelho).Distrito == null ? -1 : (item as Concelho).Distrito.Id);
            }
            else if (item is Distrito)
            {
                tabela = GLOBALS.Tabelas.TbDistrito;
                campos = GLOBALS.Tabelas.Campos.TbDistrito;
                valores = GLOBALS.Tabelas.Valores.TbDistrito;
                parameters = new Dictionary<string, object>();
                parameters.Add(valores[1], (item as Distrito).Designacao);
            }
            else
            {
                tabela = string.Empty;
                campos = null;
                valores = null;
                parameters = null;
            }
        }
        private static object InstanciaObjecto(object item, SqlDataReader reader, List<string> campos)
        {
            if (item is Arruamento)
            {
                if (campos.Count == 1 && campos[0] == "*")
                    campos = new List<string>(GLOBALS.Tabelas.Campos.TbArruamento);
                Arruamento obj = new Arruamento();
                if (campos.Contains("Id"))
                    obj.Id = (reader.IsDBNull(reader.GetOrdinal("Id")))
                                ? (int)0 : (int)reader["Id"];
                if (campos.Contains("Designacao"))
                    obj.Designacao = (reader.IsDBNull(reader.GetOrdinal("Designacao")))
                                ? "" : reader["Designacao"].ToString();
                if (campos.Contains("TipoArruamento"))
                    obj.TipoArruamento = (reader.IsDBNull(reader.GetOrdinal("TipoArruamento")))
                                ? null : new TipoArruamento() { Id = (int)reader["TipoArruamento"] };
                if (campos.Contains("Freguesia"))
                    obj.Freguesia = (reader.IsDBNull(reader.GetOrdinal("Freguesia")))
                                ? null : new Freguesia() { Id = (int)reader["Freguesia"] };
                if (campos.Contains("Inicio"))
                    obj.Inicio = (reader.IsDBNull(reader.GetOrdinal("Inicio")))
                                ? null : new Arruamento() { Id = (int)reader["Inicio"] };
                if (campos.Contains("Fim"))
                    obj.Fim = (reader.IsDBNull(reader.GetOrdinal("Fim")))
                                ? null : new Arruamento() { Id = (int)reader["Fim"] };
                if (campos.Contains("Extensao"))
                    obj.Extensao = (reader.IsDBNull(reader.GetOrdinal("Extensao")))
                                ? 0 : double.Parse(reader["Extensao"].ToString());
                if (campos.Contains("Longitude"))
                    obj.Longitude = (reader.IsDBNull(reader.GetOrdinal("Longitude")))
                                ? "" : reader["Longitude"].ToString();
                if (campos.Contains("Latitude"))
                    obj.Latitude = (reader.IsDBNull(reader.GetOrdinal("Latitude")))
                                ? "" : reader["Latitude"].ToString();
                return obj;
            }
            else if (item is TipoArruamento)
            {
                if (campos.Count == 1 && campos[0] == "*")
                    campos = new List<string>(GLOBALS.Tabelas.Campos.TbTipoArruamento);
                TipoArruamento obj = new TipoArruamento();
                if (campos.Contains("Id"))
                    obj.Id = (reader.IsDBNull(reader.GetOrdinal("Id")))
                                ? (int)0 : (int)reader["Id"];
                if (campos.Contains("Designacao"))
                    obj.Designacao = (reader.IsDBNull(reader.GetOrdinal("Designacao")))
                                ? "" : reader["Designacao"].ToString();
                return obj;
            }
            else if (item is Freguesia)
            {
                if (campos.Count == 1 && campos[0] == "*")
                    campos = new List<string>(GLOBALS.Tabelas.Campos.TbFreguesia);
                Freguesia obj = new Freguesia();
                if (campos.Contains("Id"))
                    obj.Id = (reader.IsDBNull(reader.GetOrdinal("Id")))
                                ? (int)0 : (int)reader["Id"];
                if (campos.Contains("Designacao"))
                    obj.Designacao = (reader.IsDBNull(reader.GetOrdinal("Designacao")))
                                ? "" : reader["Designacao"].ToString();
                if (campos.Contains("Concelho"))
                    obj.Concelho = (reader.IsDBNull(reader.GetOrdinal("Concelho")))
                                ? null : new Concelho() { Id = (int)reader["Concelho"] };
                return obj;
            }
            else if (item is Concelho)
            {
                if (campos.Count == 1 && campos[0] == "*")
                    campos = new List<string>(GLOBALS.Tabelas.Campos.TbConcelho);
                Concelho obj = new Concelho();
                if (campos.Contains("Id"))
                    obj.Id = (reader.IsDBNull(reader.GetOrdinal("Id")))
                                ? (int)0 : (int)reader["Id"];
                if (campos.Contains("Designacao"))
                    obj.Designacao = (reader.IsDBNull(reader.GetOrdinal("Designacao")))
                                ? "" : reader["Designacao"].ToString();
                if (campos.Contains("Distrito"))
                    obj.Distrito = (reader.IsDBNull(reader.GetOrdinal("Distrito")))
                                ? null : new Distrito() { Id = (int)reader["Distrito"] };
                return obj;
            }
            else if (item is Distrito)
            {
                if (campos.Count == 1 && campos[0] == "*")
                    campos = new List<string>(GLOBALS.Tabelas.Campos.TbDistrito);
                Distrito obj = new Distrito();
                if (campos.Contains("Id"))
                    obj.Id = (reader.IsDBNull(reader.GetOrdinal("Id")))
                                ? (int)0 : (int)reader["Id"];
                if (campos.Contains("Designacao"))
                    obj.Designacao = (reader.IsDBNull(reader.GetOrdinal("Designacao")))
                                ? "" : reader["Designacao"].ToString();
                return obj;
            }
            else
            {
                return null;
            }
        }
        private static List<object> InstanciaListaObjectos(object item, SqlDataReader reader, List<string> campos)
        {
            List<object> lista = new List<object>();
            while (reader.Read())
                lista.Add(InstanciaObjecto(item, reader, campos));
            return lista;
        }
        #endregion
    }

    /// <summary>
    /// Classe que define um arruamento
    /// </summary>
    public class Arruamento
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public TipoArruamento TipoArruamento { get; set; }
        public Freguesia Freguesia { get; set; }
        public Arruamento Inicio { get; set; }
        public Arruamento Fim { get; set; }
        public double Extensao { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
    }
    /// <summary>
    /// Classe que define um tipo de arruamento (Rua, Avenida, Praça, etc...)
    /// </summary>
    public class TipoArruamento
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
    }
    /// <summary>
    /// Classe que define uma Freguesia. Uma Freguesia tem um Concelho.
    /// </summary>
    public class Freguesia
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public Concelho Concelho { get; set; }
    }
    /// <summary>
    /// Classe que define um Concelho. Um Concelho tem um Distrito.
    /// </summary>
    public class Concelho
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public Distrito Distrito { get; set; }
    }
    /// <summary>
    /// Classe que define um Distrito.
    /// </summary>
    public class Distrito
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
    }

    /*
     * Classe que define os parâmetros globais da DLL. 
     * Aqui estão definidas as tabelas da BD, bem como os campos e os parâmetros para as queries. 
     * Enumera-se ainda o query type (CRUD).
     */
    internal static class GLOBALS
    {
        public static class Tabelas
        {
            public const string TbDistrito = "Distrito";
            public const string TbConcelho = "Concelho";
            public const string TbFreguesia = "Freguesia";
            public const string TbTipoArruamento = "TipoArruamento";
            public const string TbArruamento = "Arruamento";
            public static class Campos
            {
                public static string[] TbDistrito = { "Id", "Designacao" };
                public static string[] TbConcelho = { "Id", "Designacao", "Distrito" };
                public static string[] TbFreguesia = { "Id", "Designacao", "Concelho" };
                public static string[] TbTipoArruamento = { "Id", "Designacao" };
                public static string[] TbArruamento = { "Id", "Designacao", "TipoArruamento", "Freguesia", "Inicio", "Fim", "Extensao", "Longitude", "Latitude" };
            }
            public static class Valores
            {
                public static string[] TbDistrito = { "@Id", "@Designacao" };
                public static string[] TbConcelho = { "@Id", "@Designacao", "@Distrito" };
                public static string[] TbFreguesia = { "@Id", "@Designacao", "@Concelho" };
                public static string[] TbTipoArruamento = { "@Id", "@Designacao" };
                public static string[] TbArruamento = { "@Id", "@Designacao", "@TipoArruamento", "@Freguesia", "@Inicio", "@Fim", "@Extensao", "@Longitude", "@Latitude" };
            }
        }
        public static List<FieldInfo> GetConstants(Type type)
        {
            FieldInfo[] fieldInfos = type.GetFields(BindingFlags.Public |
                 BindingFlags.Static | BindingFlags.FlattenHierarchy);

            return fieldInfos.Where(fi => fi.IsLiteral && !fi.IsInitOnly).ToList();
        }
        public static List<T> GetConstantValues<T>(Type type)
        {
            return type
                .GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)
                .Where(fi => fi.IsLiteral && !fi.IsInitOnly && fi.FieldType == typeof(T))
                .Select(x => (T)x.GetRawConstantValue())
                .ToList();
        }
        public enum QueryType
        {
            INSERT,
            SELECT,
            UPDATE,
            DELETE
        }
    }
    /// <summary>
    /// Classe que disponibiliza informação interna da DLL.
    /// </summary>
    public static class GLOBALS_PUBLIC
    {
        /// <summary>
        /// Método que devolve uma lista com os nomes das tabelas utilizadas na BD.
        /// </summary>
        public static List<string> ListaTabelas()
        {
            return new List<string>() {
                GLOBALS.Tabelas.TbArruamento,
                GLOBALS.Tabelas.TbTipoArruamento,
                GLOBALS.Tabelas.TbFreguesia,
                GLOBALS.Tabelas.TbConcelho,
                GLOBALS.Tabelas.TbDistrito
            };
        }
        /// <summary>
        /// Método que devolve um dicionário, indexado pelos nomes das tabelas, tendo associado a cada tabela uma lista com os campos definidos na BD para essa mesma tabela.
        /// </summary>
        public static Dictionary<string, List<string>> ListaCamposTabelas()
        {
            return new Dictionary<string, List<string>>() {
                { GLOBALS.Tabelas.TbArruamento, GLOBALS.Tabelas.Campos.TbArruamento.ToList() },
                { GLOBALS.Tabelas.TbTipoArruamento, GLOBALS.Tabelas.Campos.TbTipoArruamento.ToList() },
                { GLOBALS.Tabelas.TbFreguesia, GLOBALS.Tabelas.Campos.TbFreguesia.ToList() },
                { GLOBALS.Tabelas.TbConcelho, GLOBALS.Tabelas.Campos.TbConcelho.ToList() },
                { GLOBALS.Tabelas.TbDistrito, GLOBALS.Tabelas.Campos.TbDistrito.ToList() }
            };
        }
        /// <summary>
        /// Método que devolve uma lista com os campos definidos na BD para a tabela passada por parâmetro.
        /// <para>Caso a tabela não exista, é devolvido null.</para>
        /// </summary>
        public static List<string> ListaCamposByTabela(string tabela)
        {
            List<string> listaTabelas = GLOBALS.GetConstantValues<string>(typeof(GLOBALS.Tabelas));
            switch (tabela)
            {
                case GLOBALS.Tabelas.TbArruamento:
                    return GLOBALS.Tabelas.Campos.TbArruamento.ToList();
                case GLOBALS.Tabelas.TbTipoArruamento:
                    return GLOBALS.Tabelas.Campos.TbTipoArruamento.ToList();
                case GLOBALS.Tabelas.TbFreguesia:
                    return GLOBALS.Tabelas.Campos.TbFreguesia.ToList();
                case GLOBALS.Tabelas.TbConcelho:
                    return GLOBALS.Tabelas.Campos.TbConcelho.ToList();
                case GLOBALS.Tabelas.TbDistrito:
                    return GLOBALS.Tabelas.Campos.TbDistrito.ToList();
                default:
                    return null;
            }
        }
    }
}


