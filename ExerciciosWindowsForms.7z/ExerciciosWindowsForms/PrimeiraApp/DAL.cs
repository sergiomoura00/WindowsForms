﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace PrimeiraApp
{
    public class DAL
    {
        private OleDbConnection _conexao;
        public DAL()
        {
            _conexao = new OleDbConnection();
            _conexao.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BaseDados\DBTeste.mdb";
        }

        public List<MinhasClasses.Editora> ObterTodasEditoras()
        {
            if (_conexao.State != ConnectionState.Open)
                _conexao.Open();

            OleDbCommand command = new OleDbCommand();
            command.Connection = _conexao;
            command.CommandText = "SELECT * FROM [Editora]";
            OleDbDataReader dataR = command.ExecuteReader();
            if (dataR.HasRows)
            {
                List<MinhasClasses.Editora> lista = new List<MinhasClasses.Editora>();
                while (dataR.Read())
                {
                    MinhasClasses.Editora editora = new MinhasClasses.Editora();
                    editora.Id = dataR.GetString(0);
                    editora.Nome = dataR.GetString(1);
                    lista.Add(editora);
                }
                _conexao.Close();
                return lista;
            }
            else
                _conexao.Close();
            return null;
        }

        public int InserirEditora(MinhasClasses.Editora editora)
        {
            if (_conexao.State != ConnectionState.Open)
                _conexao.Open();

            OleDbCommand command = new OleDbCommand();
            command.Connection = _conexao;
            command.CommandText = "INSERT INTO [Editora] VALUES ('" + editora.Id + "','" + editora.Nome + "')";
            int numLinhas = command.ExecuteNonQuery();
            _conexao.Close();
            return numLinhas;
        }
    }
}
