﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MinhasClasses;

namespace PrimeiraApp
{
    public partial class Testes : Form
    {
        public Testes()
        {
            InitializeComponent();
            lstBoxEditoras.DisplayMember = "Nome";
            lstBoxAutores.DisplayMember = "Nome";
            lstBoxGenerosLivros.DisplayMember = "Descricao";
            lstBoxLivros.DisplayMember = "Titulo";

            //ACEDER À BD PARA LER DADOS E PREENCHER AS LISTBOX
            //***************
            DAL objectoDAL = new DAL();
            List<Editora> listaEditoras = objectoDAL.ObterTodasEditoras();

            foreach (Editora ed in listaEditoras)
                lstBoxEditoras.Items.Add(ed);

            //***********************
            //ESTE CÓDIGO FOI MUDADO PARA DENTRO DA CLASSE DAL (Data Access Layer)
            //***********************
            //OleDbConnection conexao = new OleDbConnection();
            //conexao.ConnectionString =
            //    @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BaseDados\DBTeste.mdb";

            //if (conexao.State != ConnectionState.Open)
            //    conexao.Open();

            //OleDbCommand command = new OleDbCommand();
            //command.Connection = conexao;
            //command.CommandText = "SELECT * FROM [Editora]";
            //OleDbDataReader dataR = command.ExecuteReader();
            //if (dataR.HasRows)
            //{
            //    while (dataR.Read())
            //    {
            //        Editora editora = new Editora();
            //        editora.Id = dataR.GetString(0);
            //        editora.Nome = dataR.GetString(1);
            //        lstBoxEditoras.Items.Add(editora);
            //    }
            //}
            //conexao.Close();
        }

        private void btnNovaEditora_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovaEditora.Text))
            {
                Editora editora = new Editora()
                {
                    Nome = txtNovaEditora.Text
                };

                lstBoxEditoras.Items.Add(editora);
                txtNovaEditora.Text = "";

                //INSERIR A EDITORA NA BASE DE DADOS
                DAL objectoDAL = new DAL();
                objectoDAL.InserirEditora(editora);

                //***********************
                //ESTE CÓDIGO FOI MUDADO PARA DENTRO DA CLASSE DAL (Data Access Layer)
                //***********************
                //OleDbConnection conexao = new OleDbConnection();
                //conexao.ConnectionString =
                //    @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BaseDados\DBTeste.mdb";

                //if (conexao.State != ConnectionState.Open)
                //    conexao.Open();

                //OleDbCommand command = new OleDbCommand();
                //command.Connection = conexao;
                //command.CommandText = "INSERT INTO [Editora] VALUES ('" + editora.Id + "','" + editora.Nome + "')";
                //int numLinhas = command.ExecuteNonQuery();
                //conexao.Close();



            }
        }

        private void btnNovoAutor_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovoAutor.Text))
            {
                if (lstBoxEditoras.SelectedItems.Count > 0)
                {
                    Autor autor = new Autor() { Nome = txtNovoAutor.Text };

                    foreach (Editora editora in lstBoxEditoras.SelectedItems)
                        autor.EditorasUsadas.Add(editora);

                    lstBoxAutores.Items.Add(autor);
                    txtNovoAutor.Text = string.Empty;
                    lstBoxEditoras.SelectedIndex = -1;
                }
            }
        }

        private void lstBoxAutores_DoubleClick(object sender, EventArgs e)
        {
            Autor x = (Autor)lstBoxAutores.SelectedItems[0];
            string editoras = "";
            foreach (Editora y in x.EditorasUsadas)
            {
                editoras += y.Nome + "\n";
            }
            MessageBox.Show(string.Format("Nome do autor: {0}\nId do Autor: {1}\nEditoras usadas:\n{2}", x.Nome, x.Id, editoras));
        }

        private void btnNovoGeneroLivro_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovoGeneroLivro.Text))
            {
                GeneroLivro genero = new GeneroLivro()
                {
                    Descricao = txtNovoGeneroLivro.Text
                };
                lstBoxGenerosLivros.Items.Add(genero);
                txtNovoGeneroLivro.Text = string.Empty;
            }
        }

        private void btnNovoLivro_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNovoLivro_isbn.Text) &&
                !string.IsNullOrEmpty(txtNovoLivro_titulo.Text))
            {
                if (lstBoxGenerosLivros.SelectedItems.Count > 0)
                {
                    if (lstBoxEditoras.SelectedItems.Count == 1)
                    {
                        Livro livro = new Livro(
                            txtNovoLivro_isbn.Text,
                            txtNovoLivro_titulo.Text,
                            (GeneroLivro)lstBoxGenerosLivros.SelectedItems[0],
                            dtPickLivro.Value,
                            (Editora)lstBoxEditoras.SelectedItems[0]
                            );
                        lstBoxLivros.Items.Add(livro);
                        txtNovoLivro_isbn.Text = "";
                        txtNovoLivro_titulo.Text = "";
                        lstBoxGenerosLivros.SelectedIndex = -1;
                        lstBoxEditoras.SelectedIndex = -1;
                    }
                    else
                    {
                        MessageBox.Show("Selecionar APENAS 1 Editora!");
                    }
                }
            }
        }

        private void lstBoxLivros_DoubleClick(object sender, EventArgs e)
        {
            Livro x = (Livro)lstBoxLivros.SelectedItems[0];
            MessageBox.Show(string.Format("Nome do livro: {0}\nIsbn: {1}\nGénero: {2}\nEditora: {3}\nData Publicação: {4}", x.Titulo, x.Isbn, x.GeneroLivro.Descricao, x.Editora.Nome, x.DataPublicacao.ToString("dd-MM-yyyy")), "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }
    }
}
