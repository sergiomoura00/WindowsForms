﻿namespace PrimeiraApp
{
    partial class frmFicheiros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEscrita = new System.Windows.Forms.TabPage();
            this.btnEscrita = new System.Windows.Forms.Button();
            this.txtEscrita = new System.Windows.Forms.TextBox();
            this.tabEscritaAppend = new System.Windows.Forms.TabPage();
            this.btnEscritaAppend = new System.Windows.Forms.Button();
            this.txtEscritaAppend = new System.Windows.Forms.TextBox();
            this.tabLerFicheiro = new System.Windows.Forms.TabPage();
            this.txtLerFicheiro = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabEscrita.SuspendLayout();
            this.tabEscritaAppend.SuspendLayout();
            this.tabLerFicheiro.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabEscrita);
            this.tabControl1.Controls.Add(this.tabEscritaAppend);
            this.tabControl1.Controls.Add(this.tabLerFicheiro);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(495, 344);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabEscrita
            // 
            this.tabEscrita.Controls.Add(this.btnEscrita);
            this.tabEscrita.Controls.Add(this.txtEscrita);
            this.tabEscrita.Location = new System.Drawing.Point(4, 22);
            this.tabEscrita.Name = "tabEscrita";
            this.tabEscrita.Padding = new System.Windows.Forms.Padding(3);
            this.tabEscrita.Size = new System.Drawing.Size(487, 318);
            this.tabEscrita.TabIndex = 0;
            this.tabEscrita.Text = "Escrita em Ficheiro";
            this.tabEscrita.UseVisualStyleBackColor = true;
            // 
            // btnEscrita
            // 
            this.btnEscrita.Location = new System.Drawing.Point(406, 289);
            this.btnEscrita.Name = "btnEscrita";
            this.btnEscrita.Size = new System.Drawing.Size(75, 23);
            this.btnEscrita.TabIndex = 1;
            this.btnEscrita.Text = "Guardar";
            this.btnEscrita.UseVisualStyleBackColor = true;
            this.btnEscrita.Click += new System.EventHandler(this.btnEscrita_Click);
            // 
            // txtEscrita
            // 
            this.txtEscrita.Location = new System.Drawing.Point(7, 4);
            this.txtEscrita.Multiline = true;
            this.txtEscrita.Name = "txtEscrita";
            this.txtEscrita.Size = new System.Drawing.Size(474, 283);
            this.txtEscrita.TabIndex = 0;
            // 
            // tabEscritaAppend
            // 
            this.tabEscritaAppend.Controls.Add(this.btnEscritaAppend);
            this.tabEscritaAppend.Controls.Add(this.txtEscritaAppend);
            this.tabEscritaAppend.Location = new System.Drawing.Point(4, 22);
            this.tabEscritaAppend.Name = "tabEscritaAppend";
            this.tabEscritaAppend.Padding = new System.Windows.Forms.Padding(3);
            this.tabEscritaAppend.Size = new System.Drawing.Size(487, 318);
            this.tabEscritaAppend.TabIndex = 1;
            this.tabEscritaAppend.Text = "Escrita em Ficheiro - Append";
            this.tabEscritaAppend.UseVisualStyleBackColor = true;
            // 
            // btnEscritaAppend
            // 
            this.btnEscritaAppend.Location = new System.Drawing.Point(406, 289);
            this.btnEscritaAppend.Name = "btnEscritaAppend";
            this.btnEscritaAppend.Size = new System.Drawing.Size(75, 23);
            this.btnEscritaAppend.TabIndex = 1;
            this.btnEscritaAppend.Text = "Guardar";
            this.btnEscritaAppend.UseVisualStyleBackColor = true;
            this.btnEscritaAppend.Click += new System.EventHandler(this.btnEscritaAppend_Click);
            // 
            // txtEscritaAppend
            // 
            this.txtEscritaAppend.Location = new System.Drawing.Point(7, 7);
            this.txtEscritaAppend.Multiline = true;
            this.txtEscritaAppend.Name = "txtEscritaAppend";
            this.txtEscritaAppend.Size = new System.Drawing.Size(474, 276);
            this.txtEscritaAppend.TabIndex = 0;
            // 
            // tabLerFicheiro
            // 
            this.tabLerFicheiro.Controls.Add(this.txtLerFicheiro);
            this.tabLerFicheiro.Location = new System.Drawing.Point(4, 22);
            this.tabLerFicheiro.Name = "tabLerFicheiro";
            this.tabLerFicheiro.Size = new System.Drawing.Size(487, 318);
            this.tabLerFicheiro.TabIndex = 2;
            this.tabLerFicheiro.Text = "Ler Ficheiro";
            this.tabLerFicheiro.UseVisualStyleBackColor = true;
            this.tabLerFicheiro.Click += new System.EventHandler(this.tabLerFicheiro_Click);
            this.tabLerFicheiro.DoubleClick += new System.EventHandler(this.tabLerFicheiro_Click);
            // 
            // txtLerFicheiro
            // 
            this.txtLerFicheiro.Location = new System.Drawing.Point(4, 4);
            this.txtLerFicheiro.Multiline = true;
            this.txtLerFicheiro.Name = "txtLerFicheiro";
            this.txtLerFicheiro.Size = new System.Drawing.Size(480, 314);
            this.txtLerFicheiro.TabIndex = 0;
            // 
            // frmFicheiros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 386);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmFicheiros";
            this.Text = "frmFicheiros";
            this.tabControl1.ResumeLayout(false);
            this.tabEscrita.ResumeLayout(false);
            this.tabEscrita.PerformLayout();
            this.tabEscritaAppend.ResumeLayout(false);
            this.tabEscritaAppend.PerformLayout();
            this.tabLerFicheiro.ResumeLayout(false);
            this.tabLerFicheiro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabEscrita;
        private System.Windows.Forms.Button btnEscrita;
        private System.Windows.Forms.TextBox txtEscrita;
        private System.Windows.Forms.TabPage tabEscritaAppend;
        private System.Windows.Forms.Button btnEscritaAppend;
        private System.Windows.Forms.TextBox txtEscritaAppend;
        private System.Windows.Forms.TabPage tabLerFicheiro;
        private System.Windows.Forms.TextBox txtLerFicheiro;
    }
}