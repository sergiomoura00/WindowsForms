﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmQuantoTempoPassou : Form
    {
        public frmQuantoTempoPassou()
        {
            InitializeComponent();

            monthCalendar1.MaxDate = DateTime.Now;
            monthCalendar2.MinDate = DateTime.Now;
            monthCalendar1.MaxSelectionCount = 1;
            monthCalendar2.MaxSelectionCount = 1;

            ExecutarCalculoDatas();
            //TimeSpan TS = monthCalendar2.SelectionStart
            //    - monthCalendar1.SelectionStart;

            //lblDias.Text = TS.Days.ToString();

            //lblMeses.Text = (
            //    ((monthCalendar2.SelectionStart.Year
            //    -
            //    monthCalendar1.SelectionStart.Year)
            //    * 12)
            //    +
            //    (monthCalendar2.SelectionStart.Month
            //    -
            //    monthCalendar1.SelectionStart.Month)
            //    ).ToString();

            //lblAnos.Text =
            //    (monthCalendar2.SelectionStart.Year
            //    -
            //    monthCalendar1.SelectionStart.Year).ToString();

        }

        private void QQ_queSejaO_Calendario_DateSelected(object sender, DateRangeEventArgs e)
        {
            ExecutarCalculoDatas();
        }

        public int CalcularMesesEntre2Datas(DateTime data1,
                                            DateTime data2)
        {
            return ((data2.Year - data1.Year) * 12) +
                (data2.Month - data1.Month);
        }

        public int CalcularAnosEntre2Datas(DateTime data1,
                                           DateTime data2)
        {
            return data2.Year - data1.Year;
        }

        public void ExecutarCalculoDatas()
        {
            TimeSpan TS = monthCalendar2.SelectionStart
                - monthCalendar1.SelectionStart;
            lblDias.Text = string.Format("{0} dias", TS.Days);

            lblMeses.Text = string.Format("{0} meses",
                CalcularMesesEntre2Datas(monthCalendar1.SelectionStart, 
                monthCalendar2.SelectionStart));
            lblAnos.Text = string.Format("{0} anos",
                CalcularAnosEntre2Datas(monthCalendar1.SelectionStart, 
                monthCalendar2.SelectionStart));
        }
    }
}
