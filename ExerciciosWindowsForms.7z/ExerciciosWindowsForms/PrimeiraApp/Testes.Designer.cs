﻿namespace PrimeiraApp
{
    partial class Testes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNovaEditora = new System.Windows.Forms.TextBox();
            this.btnNovaEditora = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstBoxEditoras = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstBoxAutores = new System.Windows.Forms.ListBox();
            this.btnNovoAutor = new System.Windows.Forms.Button();
            this.txtNovoAutor = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lstBoxGenerosLivros = new System.Windows.Forms.ListBox();
            this.btnNovoGeneroLivro = new System.Windows.Forms.Button();
            this.txtNovoGeneroLivro = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstBoxLivros = new System.Windows.Forms.ListBox();
            this.btnNovoLivro = new System.Windows.Forms.Button();
            this.txtNovoLivro_titulo = new System.Windows.Forms.TextBox();
            this.txtNovoLivro_isbn = new System.Windows.Forms.TextBox();
            this.dtPickLivro = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNovaEditora
            // 
            this.txtNovaEditora.Location = new System.Drawing.Point(6, 19);
            this.txtNovaEditora.Name = "txtNovaEditora";
            this.txtNovaEditora.Size = new System.Drawing.Size(139, 20);
            this.txtNovaEditora.TabIndex = 0;
            // 
            // btnNovaEditora
            // 
            this.btnNovaEditora.Location = new System.Drawing.Point(151, 17);
            this.btnNovaEditora.Name = "btnNovaEditora";
            this.btnNovaEditora.Size = new System.Drawing.Size(75, 23);
            this.btnNovaEditora.TabIndex = 1;
            this.btnNovaEditora.Text = "Criar";
            this.btnNovaEditora.UseVisualStyleBackColor = true;
            this.btnNovaEditora.Click += new System.EventHandler(this.btnNovaEditora_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstBoxEditoras);
            this.groupBox1.Controls.Add(this.btnNovaEditora);
            this.groupBox1.Controls.Add(this.txtNovaEditora);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 160);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Editoras";
            // 
            // lstBoxEditoras
            // 
            this.lstBoxEditoras.FormattingEnabled = true;
            this.lstBoxEditoras.Location = new System.Drawing.Point(7, 46);
            this.lstBoxEditoras.Name = "lstBoxEditoras";
            this.lstBoxEditoras.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstBoxEditoras.Size = new System.Drawing.Size(219, 108);
            this.lstBoxEditoras.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstBoxAutores);
            this.groupBox2.Controls.Add(this.btnNovoAutor);
            this.groupBox2.Controls.Add(this.txtNovoAutor);
            this.groupBox2.Location = new System.Drawing.Point(251, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(284, 159);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Autores";
            // 
            // lstBoxAutores
            // 
            this.lstBoxAutores.FormattingEnabled = true;
            this.lstBoxAutores.Location = new System.Drawing.Point(6, 46);
            this.lstBoxAutores.Name = "lstBoxAutores";
            this.lstBoxAutores.Size = new System.Drawing.Size(271, 108);
            this.lstBoxAutores.TabIndex = 2;
            this.lstBoxAutores.DoubleClick += new System.EventHandler(this.lstBoxAutores_DoubleClick);
            // 
            // btnNovoAutor
            // 
            this.btnNovoAutor.Location = new System.Drawing.Point(202, 17);
            this.btnNovoAutor.Name = "btnNovoAutor";
            this.btnNovoAutor.Size = new System.Drawing.Size(75, 23);
            this.btnNovoAutor.TabIndex = 1;
            this.btnNovoAutor.Text = "Criar";
            this.btnNovoAutor.UseVisualStyleBackColor = true;
            this.btnNovoAutor.Click += new System.EventHandler(this.btnNovoAutor_Click);
            // 
            // txtNovoAutor
            // 
            this.txtNovoAutor.Location = new System.Drawing.Point(6, 19);
            this.txtNovoAutor.Name = "txtNovoAutor";
            this.txtNovoAutor.Size = new System.Drawing.Size(190, 20);
            this.txtNovoAutor.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lstBoxGenerosLivros);
            this.groupBox3.Controls.Add(this.btnNovoGeneroLivro);
            this.groupBox3.Controls.Add(this.txtNovoGeneroLivro);
            this.groupBox3.Location = new System.Drawing.Point(12, 179);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(232, 163);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Géneros de Livros";
            // 
            // lstBoxGenerosLivros
            // 
            this.lstBoxGenerosLivros.FormattingEnabled = true;
            this.lstBoxGenerosLivros.Location = new System.Drawing.Point(7, 47);
            this.lstBoxGenerosLivros.Name = "lstBoxGenerosLivros";
            this.lstBoxGenerosLivros.Size = new System.Drawing.Size(219, 108);
            this.lstBoxGenerosLivros.TabIndex = 2;
            // 
            // btnNovoGeneroLivro
            // 
            this.btnNovoGeneroLivro.Location = new System.Drawing.Point(151, 18);
            this.btnNovoGeneroLivro.Name = "btnNovoGeneroLivro";
            this.btnNovoGeneroLivro.Size = new System.Drawing.Size(75, 23);
            this.btnNovoGeneroLivro.TabIndex = 1;
            this.btnNovoGeneroLivro.Text = "Criar";
            this.btnNovoGeneroLivro.UseVisualStyleBackColor = true;
            this.btnNovoGeneroLivro.Click += new System.EventHandler(this.btnNovoGeneroLivro_Click);
            // 
            // txtNovoGeneroLivro
            // 
            this.txtNovoGeneroLivro.Location = new System.Drawing.Point(7, 20);
            this.txtNovoGeneroLivro.Name = "txtNovoGeneroLivro";
            this.txtNovoGeneroLivro.Size = new System.Drawing.Size(138, 20);
            this.txtNovoGeneroLivro.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dtPickLivro);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.lstBoxLivros);
            this.groupBox4.Controls.Add(this.btnNovoLivro);
            this.groupBox4.Controls.Add(this.txtNovoLivro_titulo);
            this.groupBox4.Controls.Add(this.txtNovoLivro_isbn);
            this.groupBox4.Location = new System.Drawing.Point(251, 179);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(284, 163);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Livros";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Titulo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "ISBN";
            // 
            // lstBoxLivros
            // 
            this.lstBoxLivros.FormattingEnabled = true;
            this.lstBoxLivros.Location = new System.Drawing.Point(6, 74);
            this.lstBoxLivros.Name = "lstBoxLivros";
            this.lstBoxLivros.Size = new System.Drawing.Size(271, 82);
            this.lstBoxLivros.TabIndex = 3;
            this.lstBoxLivros.DoubleClick += new System.EventHandler(this.lstBoxLivros_DoubleClick);
            // 
            // btnNovoLivro
            // 
            this.btnNovoLivro.Location = new System.Drawing.Point(202, 44);
            this.btnNovoLivro.Name = "btnNovoLivro";
            this.btnNovoLivro.Size = new System.Drawing.Size(75, 23);
            this.btnNovoLivro.TabIndex = 2;
            this.btnNovoLivro.Text = "Criar";
            this.btnNovoLivro.UseVisualStyleBackColor = true;
            this.btnNovoLivro.Click += new System.EventHandler(this.btnNovoLivro_Click);
            // 
            // txtNovoLivro_titulo
            // 
            this.txtNovoLivro_titulo.Location = new System.Drawing.Point(55, 47);
            this.txtNovoLivro_titulo.Name = "txtNovoLivro_titulo";
            this.txtNovoLivro_titulo.Size = new System.Drawing.Size(141, 20);
            this.txtNovoLivro_titulo.TabIndex = 1;
            // 
            // txtNovoLivro_isbn
            // 
            this.txtNovoLivro_isbn.Location = new System.Drawing.Point(55, 20);
            this.txtNovoLivro_isbn.Name = "txtNovoLivro_isbn";
            this.txtNovoLivro_isbn.Size = new System.Drawing.Size(55, 20);
            this.txtNovoLivro_isbn.TabIndex = 0;
            // 
            // dtPickLivro
            // 
            this.dtPickLivro.Location = new System.Drawing.Point(117, 20);
            this.dtPickLivro.Name = "dtPickLivro";
            this.dtPickLivro.Size = new System.Drawing.Size(160, 20);
            this.dtPickLivro.TabIndex = 6;
            // 
            // Testes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 354);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Testes";
            this.Text = "Testes";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtNovaEditora;
        private System.Windows.Forms.Button btnNovaEditora;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstBoxEditoras;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstBoxAutores;
        private System.Windows.Forms.Button btnNovoAutor;
        private System.Windows.Forms.TextBox txtNovoAutor;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox lstBoxGenerosLivros;
        private System.Windows.Forms.Button btnNovoGeneroLivro;
        private System.Windows.Forms.TextBox txtNovoGeneroLivro;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstBoxLivros;
        private System.Windows.Forms.Button btnNovoLivro;
        private System.Windows.Forms.TextBox txtNovoLivro_titulo;
        private System.Windows.Forms.TextBox txtNovoLivro_isbn;
        private System.Windows.Forms.DateTimePicker dtPickLivro;
    }
}