﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmCumprimentos : Form
    {
        public frmCumprimentos()
        {
            InitializeComponent();
            labelMostra.Text = "";
            this.Height = 110;
            this.AcceptButton = btnClique;
            this.CancelButton = buttonLimpar;
        }

        private void btnClique_Click(object sender, EventArgs e)
        {
            labelMostra.Text = textModo.Text + " " + textNome.Text + "!!";
            this.Height = 190;
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            textModo.Text = "";
            textNome.Text = "";
            labelMostra.Text = "";
            this.Height = 110;
        }
    }
}
