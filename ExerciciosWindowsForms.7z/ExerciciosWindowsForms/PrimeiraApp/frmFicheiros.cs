﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmFicheiros : Form
    {
        public frmFicheiros()
        {
            InitializeComponent();
        }

        private void btnEscrita_Click(object sender, EventArgs e)
        {
            EscreverFicheiro(txtEscrita.Text, false);
        }

        private void btnEscritaAppend_Click(object sender, EventArgs e)
        {
            EscreverFicheiro(txtEscritaAppend.Text, true);
        }

        private void EscreverFicheiro(string txt, bool append)
        {
            if (!string.IsNullOrEmpty(txt))
            {
                try
                {
                    SaveFileDialog dialogo = new SaveFileDialog();
                    dialogo.InitialDirectory = @"c:\";
                    dialogo.Filter = "Ficheiros de Texto (*.txt)|*.txt|Qualquer tipo (*.*)|*.*";
                    DialogResult resultado = dialogo.ShowDialog();
                    if (resultado == DialogResult.OK)
                    {
                        //************
                        //Podemos testar se o objecto dialogo é null,
                        //se tem a propriedade FileName preenchida,
                        //se o ficheiro que foi indicado existe 
                        //(caso seja para fazer append, por exemplo)
                        //************
                        //if(dialogo != null 
                        //    && !string.IsNullOrEmpty(dialogo.FileName)
                        //    && System.IO.File.Exists(dialogo.FileName))
                        //{ }
                        System.IO.StreamWriter sw =
                            new System.IO.StreamWriter(dialogo.FileName, append);
                        sw.WriteLine(txt);
                        sw.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(string.Format("Tipo de Exceção: {0}\nMensagem: {1}", ex.GetType().ToString(), ex.Message));
                }
            }
        }

        private void tabLerFicheiro_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage == tabLerFicheiro)
            {
                try
                {
                    OpenFileDialog dialogo = new OpenFileDialog();
                    dialogo.InitialDirectory = System.IO.Directory.GetCurrentDirectory();

                    DialogResult resultado = dialogo.ShowDialog();
                    if (resultado == DialogResult.OK)
                    {
                        System.IO.StreamReader sr =
                            new System.IO.StreamReader(dialogo.FileName);

                        string texto;
                        while ((texto = sr.ReadLine()) != null)
                        {
                            string[] textoPartido = texto.Split('|');
                            txtLerFicheiro.Text += "Nome: " + textoPartido[0];
                            txtLerFicheiro.Text += System.Environment.NewLine;
                            txtLerFicheiro.Text += "Idade: " + textoPartido[1];
                            txtLerFicheiro.Text += System.Environment.NewLine;
                            txtLerFicheiro.Text += "**************";
                            txtLerFicheiro.Text += System.Environment.NewLine;
                        }

                        sr.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
