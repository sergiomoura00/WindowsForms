﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeiraApp
{
    public partial class frmNomeEmail : Form
    {
        public frmNomeEmail()
        {
            InitializeComponent();
            lblNome.Text = lblEmail1.Text 
                = lblEmail2.Text = string.Empty;
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            lblNome.Text = Util.Texto.Exercicio5.NomeReduzido(
                    txtNomeCompleto.Text
                );
            lblEmail1.Text = Util.Texto.Exercicio5.EmailCompleto(
                    txtNomeCompleto.Text
                );
            lblEmail2.Text = Util.Texto.Exercicio5.EmailReduzido(
                    txtNomeCompleto.Text
                );
            //MessageBox.Show(Util.Texto.Exercicio10.Substitui("kajsljas  awa kljã aãé"));
            //MessageBox.Show(Util.Texto.Exercicio10.SubstituiTemp("kajsljas  awa kljã aãé"));
            //string texto = txtNomeCompleto.Text;

            //texto = texto.Replace("á","a");
            //texto = texto.Replace("ó", "o");

            //string[] textoPartido = texto.Split(' ');

            //string primeiroNome = textoPartido[0];

            //string ultimoNome = textoPartido[textoPartido.Length - 1];

            //lblNome.Text = string.Format("{0} {1}",primeiroNome, ultimoNome);

            //lblEmail1.Text = string.Format("{0}.{1}@xpto.pt"
            //    ,primeiroNome.ToLower(), ultimoNome.ToLower()) ;

            //lblEmail2.Text = string.Format("{0}{1}@xpto.pt"
            //    , primeiroNome.ToLower()[0], ultimoNome.ToLower());
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNomeCompleto.Text = lblNome.Text = lblEmail1.Text
                = lblEmail2.Text = string.Empty;
        }
    }
}
