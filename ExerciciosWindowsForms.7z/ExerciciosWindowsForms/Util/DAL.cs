﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util
{
    #region Classe de acesso a dados
    public class DAL
    {
        private SqlConnection _conn;
        public DAL()
        {
            _conn = new SqlConnection("Data Source=localhost\\sqlexpress;Initial Catalog=Teste;Trusted_Connection=True;");
            //Verificar se a conexão à base de dados está fechada
            //caso esteja fechada (se não aberta), abrir
            if (_conn.State != System.Data.ConnectionState.Open)
                _conn.Open();
        }

        #region CREATE
        public bool InserirFuncionario(Funcionario f)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _conn;
            cmd.CommandText = @"INSERT INTO [Funcionarios]
                                       ([primeiro_nome]
                                       ,[ultimo_nome]
                                       ,[data_nascimento])
                                 VALUES
                                       (@p,@u,@dt)";
            cmd.Parameters.AddWithValue("@p", f.PNome);
            cmd.Parameters.AddWithValue("@u", f.UNome);
            cmd.Parameters.AddWithValue("@dt", f.DtNascimento);

            int x = cmd.ExecuteNonQuery();
            if (x > 0)
                return true;
            else
                return false;
        }
        #endregion
        #region READ
        public Funcionario ObterFuncionario(int id)
        {
            SqlCommand command = new SqlCommand("SELECT * FROM [funcionarios] WHERE id=" + id, _conn);

            SqlDataReader dataR = command.ExecuteReader();

            if (dataR.HasRows)
            {
                dataR.Read();
                Funcionario f = new Funcionario();
                f.Id = dataR.GetInt32(0);
                f.PNome = dataR.GetString(1);
                f.UNome = dataR.GetString(2);
                f.DtNascimento = dataR.GetDateTime(3);
                dataR.Close();
                return f;
            }
            return null;
        }
        public List<Funcionario> ObterTodosOsFuncionarios()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM [funcionarios]", _conn);

            SqlDataReader dataR = command.ExecuteReader();

            if (dataR.HasRows)
            {
                List<Funcionario> lista = new List<Funcionario>();
                while (dataR.Read())
                {
                    Funcionario f = new Funcionario();
                    f.Id = dataR.GetInt32(0);
                    f.PNome = dataR.GetString(1);
                    f.UNome = dataR.GetString(2);
                    f.DtNascimento = dataR.GetDateTime(3);
                    lista.Add(f);
                }
                dataR.Close();
                return lista;
            }
            return null;
        }
        public Produto ObterProduto(string Id)
        {
            //ligar à bd ?
            //O construtor ligou. Usar apenas o _conn junto com o SqlCommand

            //criar o comando
            SqlCommand command = new SqlCommand("SELECT * FROM [Produtos] WHERE idProduto=@id", _conn);

            //Acrescentar os parameters ao comando sql
            command.Parameters.AddWithValue("@id", Id);
            //command.Parameters.Add("@id", SqlDbType.VarChar).Value = Id;

            //executar o comando
            SqlDataReader dataR = command.ExecuteReader();

            //ler os dados
            if (dataR.HasRows)
            {
                //cada vez que chamamos o dataR.Read() lemos uma linha de dados
                //Neste caso, como só pode devolver uma no máximo, fazemos o Read uma vez apenas
                dataR.Read();

                //preencher o objecto de saída
                Produto p = new Produto();
                p.IdProduto = dataR.GetString(0);
                p.NomeProduto = dataR.GetString(1);
                p.DescProduto = dataR.GetString(2);
                p.QtdStock = dataR.GetInt32(3);

                //retornar resultados
                return p;
            }

            //retornar caso não tenha dados para ler
            return null;
        }
        public List<Produto> ObterProdutosByNome(string nome_a_procurar)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _conn;
            cmd.CommandText = "SELECT * FROM [Produtos] WHERE nomeProduto LIKE '%@n%'";
            cmd.Parameters.AddWithValue("@n", nome_a_procurar);

            SqlDataReader dataR = cmd.ExecuteReader();

            if (dataR.HasRows)
            {
                List<Produto> lista = new List<Produto>();
                while (dataR.Read())
                {
                    Produto p = new Produto();
                    p.IdProduto = dataR.GetString(0);
                    p.NomeProduto = dataR.GetString(1);
                    p.DescProduto = dataR.GetString(2);
                    p.QtdStock = dataR.GetInt32(3);
                    lista.Add(p);
                }
                return lista;
            }
            return null;
        }
        #endregion
        #region UPDATE
        public bool UpdateFuncionario(Funcionario f)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _conn;
            cmd.CommandText = @"UPDATE [Funcionarios]
                                SET [primeiro_nome]=@p,
                                    [ultimo_nome]=@u,
                                    [data_nascimento]=@dt
                                WHERE [id]=@i";
            cmd.Parameters.AddWithValue("@p", f.PNome);
            cmd.Parameters.AddWithValue("@u", f.UNome);
            cmd.Parameters.AddWithValue("@dt", f.DtNascimento);
            cmd.Parameters.AddWithValue("@i", f.Id);

            int x = cmd.ExecuteNonQuery();
            if (x > 0)
                return true;
            else
                return false;
        }
        #endregion
        #region DELETE
        public bool DeleteFuncionario(int id)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _conn;
            cmd.CommandText = @"DELETE FROM [Funcionarios]
                                WHERE [id]=@i";
            cmd.Parameters.AddWithValue("@i", id);

            int x = cmd.ExecuteNonQuery();
            if (x > 0)
                return true;
            else
                return false;
        }
        #endregion
    }
    #endregion

    #region Classes de Objectos da BD
    public class Funcionario
    {
        public int Id { get; set; }
        public string PNome { get; set; }
        public string UNome { get; set; }
        public DateTime DtNascimento { get; set; }
    }
    public class Produto
    {
        public string IdProduto { get; set; }
        public string NomeProduto { get; set; }
        public string DescProduto { get; set; }
        public int QtdStock { get; set; }
    }
    #endregion
}
